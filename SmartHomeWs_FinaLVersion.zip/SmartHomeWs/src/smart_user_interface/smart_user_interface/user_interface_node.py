import rclpy
from rclpy.node import Node
from rclpy.action import ActionClient
from std_msgs.msg import String
from std_srvs.srv import Empty
from custom_action_interfaces.action import DimLights  # Ensure this custom action is defined and imported correctly.


class UserInterfaceNode(Node):
    def __init__(self):
        super().__init__('user_interface_node')

        # Create publishers
        self.light_command_publisher = self.create_publisher(String, '/light_command', 10)
        self.temperature_command_publisher = self.create_publisher(String, '/temperature_command', 10)

        # Create subscribers
        self.security_state_subscriber = self.create_subscription(
            String, '/security_state', self.state_callback, 10
        )

        # Create service clients
        self.arm_client = self.create_client(Empty, '/arm_security')
        self.disarm_client = self.create_client(Empty, '/disarm_security')

        # Create dim lights action client
        self._dim_lights_client = ActionClient(self, DimLights, 'dim_lights')

        # Initialize security state
        self.security_state = "UNKNOWN"
        self.get_logger().info("UserInterfaceNode started.")
        self.get_logger().info("Waiting for security state updates...")
        self.run()

    def state_callback(self, msg):
        """Callback to update security state when received."""
        self.security_state = msg.data
        self.get_logger().info(f"Security State updated: {self.security_state}")

    def run(self):
        """Main menu loop."""
        while rclpy.ok():
            # Display menu options
            print("\n--- User Interface ---")
            print("1. Control Lights (ON, OFF)")
            print("2. Arm Security System")
            print("3. Disarm Security System")
            print("4. Set Target Temperature")
            print("5. Dim Lights (Set Brightness)")

            choice = input("Enter your choice (1/2/3/4/5): ").strip()

            if choice == '1':
                command = input("Enter light command (ON, OFF): ").strip()
                if command.upper() in ['ON', 'OFF'] :
                    self.light_command_publisher.publish(String(data=command))
                    self.get_logger().info(f"Light command sent: {command}")
                else:
                    self.get_logger().warn("Invalid light command.")
            elif choice == '2':
                self.arm_security()
            elif choice == '3':
                self.disarm_security()
            elif choice == '4':
                command = input("Enter temperature command (SET <value>): ").strip()
                if command.upper().startswith("SET"):
                    self.temperature_command_publisher.publish(String(data=command))
                    self.get_logger().info(f"Temperature command sent: {command}")
                else:
                    self.get_logger().warn("Invalid temperature command format.")
            elif choice == '5':
                target_brightness = input("Enter target brightness (0-100): ").strip()
                try:
                    target_brightness = float(target_brightness)  # Convert input directly to float
                    if 0.0 <= target_brightness <= 100.0:  # Validate range as floats
                        self.send_dim_lights_goal(target_brightness)
                    else:
                        self.get_logger().warn("Brightness must be between 0 and 100.")
                except ValueError:
                    self.get_logger().warn("Invalid brightness value.")


    def arm_security(self):
        """Send request to arm the security system."""
        if self.arm_client.service_is_ready():
            self.arm_client.call_async(Empty.Request())
            self.get_logger().info("Request to arm security system sent.")
        else:
            self.get_logger().error("Arm service is not available.")

    def disarm_security(self):
        """Send request to disarm the security system."""
        if self.disarm_client.service_is_ready():
            self.disarm_client.call_async(Empty.Request())
            self.get_logger().info("Request to disarm security system sent.")
        else:
            self.get_logger().error("Disarm service is not available.")

    def send_dim_lights_goal(self, target_brightness):
        """Send a goal to the dim lights action server."""
        goal_msg = DimLights.Goal()
        # Convert target_brightness to float before assigning
        goal_msg.target_brightness = float(target_brightness)

        self.get_logger().info("Waiting for dim lights action server...")
        self._dim_lights_client.wait_for_server()

        # Send goal
        self.get_logger().info("Sending dim lights goal...")
        self._send_goal_future = self._dim_lights_client.send_goal_async(
            goal_msg, feedback_callback=self.dim_lights_feedback_callback
        )
        self._send_goal_future.add_done_callback(self.dim_lights_goal_response_callback)


    def dim_lights_goal_response_callback(self, future):
        goal_handle = future.result()
        if not goal_handle.accepted:
            self.get_logger().info("Dimming goal rejected.")
            return

        self.get_logger().info("Dimming goal accepted. Waiting for result...")
        self._get_result_future = goal_handle.get_result_async()
        self._get_result_future.add_done_callback(self.dim_lights_result_callback)

    def dim_lights_feedback_callback(self, feedback_msg):
        feedback = feedback_msg.feedback
        # Assuming the field is `current_brightness` as per DimLights.action
        self.get_logger().info(f"Brightness feedback received: {feedback.current_brightness}")

    def dim_lights_result_callback(self, future):
        result = future.result().result
        if result.success:
            self.get_logger().info(f"Dimming action succeeded! Brightness set to {result.brightness:.2f}")
        else:
            self.get_logger().warn("Dimming action failed.")


def main(args=None):
    rclpy.init(args=args)
    node = UserInterfaceNode()

    try:
        rclpy.spin(node)
    except KeyboardInterrupt:
        pass
    finally:
        node.destroy_node()
        rclpy.shutdown()


if __name__ == '__main__':
    main()

