from setuptools import find_packages, setup

package_name = 'smart_user_interface'

setup(
    name=package_name,
    version='0.0.0',
    packages=find_packages(exclude=['test']),
    data_files=[
        ('share/ament_index/resource_index/packages',
            ['resource/' + package_name]),
        ('share/' + package_name, ['package.xml']),
    ],
    install_requires=['setuptools',
                      'rclpy',
                      'std_msgs',
                      'std_srvs',
                      'custom_action_interfaces'],
    zip_safe=True,
    maintainer='ahmadachaji',
    maintainer_email='ahmadachaji@todo.todo',
    description='TODO: Package description',
    license='Apache-2.0',
    tests_require=['pytest'],
    entry_points={
        'console_scripts': [
         'user_interface_node = smart_user_interface.user_interface_node:main',
         'light_control_node = smart_home.light_control_node:main',
         'temperature_control_node = smart_home.temperature_control_node:main',
         'security_node = smart_home.security_node:main',
         'dim_lights_action_server = smart_home.dim_lights_action_server_node:main',
        ],
    },
)
