# Import ROS2 Python libraries
import rclpy
from rclpy.node import Node
from rclpy.action import ActionServer
from std_msgs.msg import Float32, String
from custom_action_interfaces.action import DimLights  # Assuming DimLights is defined
import random

# Lighting Control Node with Action Server for dimming lights
class LightControlNode(Node):
    def __init__(self):
        super().__init__('light_control_node')
        # Publishers
        self.ambient_light_publisher = self.create_publisher(Float32, '/ambient_light', 10)
        self.brightness_publisher = self.create_publisher(Float32, '/brightness', 10)
        self.current_brightness_publisher = self.create_publisher(Float32, '/current_brightness', 10)
        # Subscribers
        self.command_subscriber = self.create_subscription(String, '/light_command', self.handle_command, 10)
        # Timer for simulating ambient light
        self.timer = self.create_timer(5.0, self.simulate_ambient_light)
        self.light_state = "OFF"
        self.brightness = 0.0
        
        # Action Server initialization (dim_lights)
        self._action_server = ActionServer(
            self,
            DimLights,
            'dim_lights',
            self.execute_dimming_callback
        )
        self.current_brightness = 0 + int(random.uniform(0, 100)) # For dimming action logic

        self.get_logger().info("LightControlNode with DimLightsActionServer started.")

    # Simulate ambient light
    def simulate_ambient_light(self):
        if self.light_state == "OFF":
            return
        elif self.light_state == "DIM":  # Skip simulation when dimming
            return

        # Simulate ambient light level
        ambient_light_level = random.uniform(0.0, 100.0)
        self.ambient_light_publisher.publish(Float32(data=ambient_light_level))

        # Adjust brightness based on ambient light
        self.brightness = max(0.0, 100.0 - ambient_light_level)
        self.brightness_publisher.publish(Float32(data=self.brightness))

        # Log ambient light and brightness
        self.get_logger().info(f"Ambient Light Level: {ambient_light_level:.2f}, Adjusted Brightness: {self.brightness:.2f}")

    # Handle incoming commands
    def handle_command(self, msg):
        command = msg.data.upper()

        if command == "ON":
            self.light_state = "ON"
            self.get_logger().info("Light turned ON.")
        elif command == "OFF":
            self.light_state = "OFF"
            self.brightness = 0.0
            self.get_logger().info("Light turned OFF.")
        elif command.startswith("DIM"):
            # Start the dim_lights action server behavior
            self.light_state = "DIM"
            self.get_logger().info("DIM command received. Ready to execute dimming...")

    # Dimming action server callback
    def execute_dimming_callback(self, goal_handle):
        self.get_logger().info(f"Received dimming request: Target brightness {goal_handle.request.target_brightness}")
        feedback_msg = DimLights.Feedback()
        target = goal_handle.request.target_brightness

        # Gradually adjust brightness towards target
        while abs(self.current_brightness - target) > 0.1:
            # Incrementally move brightness towards target
            if self.current_brightness < target:
                self.current_brightness += 1.0
            elif self.current_brightness > target:
                self.current_brightness -= 1.0

            # Publish feedback and current brightness
            feedback_msg.current_brightness = self.current_brightness
            goal_handle.publish_feedback(feedback_msg)
            self.current_brightness_publisher.publish(Float32(data=self.current_brightness))
            self.get_logger().info(f"Adjusting brightness: {self.current_brightness}")

            # Simulate time for gradual adjustment
            rclpy.spin_once(self, timeout_sec=0.5)

        # Succeed the action
        goal_handle.succeed()
        result = DimLights.Result()
        result.success = True
        self.get_logger().info("Target brightness achieved.")
        return result

# Main function to start the node
def main(args=None):
    rclpy.init(args=args)
    node = LightControlNode()

    try:
        rclpy.spin(node)
    except KeyboardInterrupt:
        pass
    finally:
        node.destroy_node()
        rclpy.shutdown()

if __name__ == '__main__':
    main()

