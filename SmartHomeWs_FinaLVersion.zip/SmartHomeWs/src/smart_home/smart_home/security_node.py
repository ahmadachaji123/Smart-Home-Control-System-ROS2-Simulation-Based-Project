import rclpy
from rclpy.node import Node
from std_msgs.msg import String, Bool
from std_srvs.srv import Empty
import random

class SecurityNode(Node):
    def __init__(self):
        super().__init__('security_node')

        # Security state
        self.security_state = "DISARMED"

        # Publishers
        self.security_state_pub = self.create_publisher(String, '/security_state', 10)
        self.motion_detected_pub = self.create_publisher(Bool, '/motion_detected', 10)

        # Subscribers
        self.light_command_sub = self.create_subscription(String, '/light_command', self.handle_light_command, 10)

        # Services
        self.create_service(Empty, '/arm_security', self.arm_security)
        self.create_service(Empty, '/disarm_security', self.disarm_security)

        # Timer for motion detection
        self.motion_timer = self.create_timer(5.0, self.simulate_motion)

        self.get_logger().info("Security Node initialized.")

    def handle_light_command(self, msg):
        """Log the light command received."""
        self.get_logger().info(f"Light command received: {msg.data}")

    def arm_security(self, request, response):
        """Arm the security system."""
        if self.security_state != "ARMED":
            self.security_state = "ARMED"
            self.get_logger().info("Security system armed.")
            self.publish_security_state()
        else:
            self.get_logger().info("Security system is already armed.")
        return response

    def disarm_security(self, request, response):
        """Disarm the security system."""
        if self.security_state != "DISARMED":
            self.security_state = "DISARMED"
            self.get_logger().info("Security system disarmed.")
            self.publish_security_state()
        else:
            self.get_logger().info("Security system is already disarmed.")
        return response

    def publish_security_state(self):
        """Publish the current security state."""
        msg = String()
        msg.data = self.security_state
        self.security_state_pub.publish(msg)

    def simulate_motion(self):
        """Simulate random motion detection."""
        motion_detected = random.choice([True, False])
        msg = Bool()
        msg.data = motion_detected
        self.motion_detected_pub.publish(msg)
        self.get_logger().info(f"Published security state: {self.security_state}")
        
        if motion_detected:
            self.get_logger().info("Motion detected!")
            if self.security_state == "ARMED":
                self.trigger_alarm()
        #   else:
        #       self.get_logger().info("Motion detected.")
        else:
            self.get_logger().info("No motion detected")

    def trigger_alarm(self):
        """Trigger the alarm when motion is detected in an armed state."""
        if self.security_state == "ARMED":
            self.get_logger().warn("ALARM TRIGGERED!")
            # Maintain "ARMED" state; log the alarm as a separate event
        else:
            self.get_logger().info("Alarm not triggered because the system is not armed.")

def main(args=None):
    rclpy.init(args=args)
    node = SecurityNode()

    try:
        rclpy.spin(node)
    except KeyboardInterrupt:
        pass
    finally:
        node.destroy_node()
        rclpy.shutdown()

if __name__ == '__main__':
    main()



