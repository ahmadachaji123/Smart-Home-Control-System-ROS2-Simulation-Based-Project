# Import ROS2 Python libraries
import rclpy
from rclpy.node import Node
from std_msgs.msg import Float32, String  # Added String for command topic
import random

class TemperatureControlNode(Node):
    def __init__(self):
        super().__init__('temperature_control_node')
        self.target_temperature = 22.0  # Default target temperature in °C
        self.current_temperature = 0.0
        self.heater_on = False
        self.cooler_on = False

        # Publishers
        self.temperature_publisher = self.create_publisher(Float32, '/temperature', 10)
        self.control_publisher = self.create_publisher(Float32, '/temperature_control', 10)

        # Subscriber for commands
        self.command_subscriber = self.create_subscription(
            String,
            '/temperature_command',
            self.handle_command,
            10
        )

        # Timer to simulate temperature updates
        self.timer = self.create_timer(5.0, self.update_temperature)
        self.get_logger().info("TemperatureControlNode started.")

    def update_temperature(self):
        # Simulate temperature readings
        self.current_temperature = random.uniform(15.0, 30.0)  # Random temperature in °C
        self.temperature_publisher.publish(Float32(data=self.current_temperature))

        # Climate control logic
        if self.current_temperature < self.target_temperature - 1.0:
            self.heater_on = True
            self.cooler_on = False
        elif self.current_temperature > self.target_temperature + 1.0:
            self.heater_on = False
            self.cooler_on = True
        else:
            self.heater_on = False
            self.cooler_on = False

        # Publish control status
        control_status = 1.0 if self.heater_on else -1.0 if self.cooler_on else 0.0
        self.control_publisher.publish(Float32(data=control_status))

        # Log temperature and control status
        heater_status = "ON" if self.heater_on else "OFF"
        cooler_status = "ON" if self.cooler_on else "OFF"
        self.get_logger().info(
            f"Current Temp: {self.current_temperature:.2f}°C | Target Temp: {self.target_temperature}°C | "
            f"Heater: {heater_status} | Cooler: {cooler_status}"
        )

    def handle_command(self, msg):
        command = msg.data.strip().upper()
        if command.startswith("SET"):
            # Example: "SET 25" to set target temperature to 25°C
            try:
                new_target = float(command.split()[1])
                self.target_temperature = new_target
                self.get_logger().info(f"Target temperature set to {new_target}°C")
            except (IndexError, ValueError):
                self.get_logger().error("Invalid SET command. Use: 'SET <value>'")
        elif command == "OFF":
            # Turn off the system (disable heating and cooling)
            self.heater_on = False
            self.cooler_on = False
            self.get_logger().info("Temperature control system turned off.")
        elif command == "STATUS":
            # Log the current status
            heater_status = "ON" if self.heater_on else "OFF"
            cooler_status = "ON" if self.cooler_on else "OFF"
            self.get_logger().info(
                f"Current Temp: {self.current_temperature:.2f}°C | Target Temp: {self.target_temperature}°C | "
                f"Heater: {heater_status} | Cooler: {cooler_status}"
            )
        else:
            self.get_logger().warn(f"Unknown command: {command}")

# Main function to run the node
def main(args=None):
    rclpy.init(args=args)
    node = TemperatureControlNode()
    try:
        rclpy.spin(node)
    except KeyboardInterrupt:
        pass
    finally:
        node.destroy_node()
        rclpy.shutdown()

if __name__ == '__main__':
    main()



