// generated from rosidl_typesupport_fastrtps_c/resource/idl__rosidl_typesupport_fastrtps_c.h.em
// with input from custom_action_interfaces:action/DimLights.idl
// generated code does not contain a copyright notice
#ifndef CUSTOM_ACTION_INTERFACES__ACTION__DETAIL__DIM_LIGHTS__ROSIDL_TYPESUPPORT_FASTRTPS_C_H_
#define CUSTOM_ACTION_INTERFACES__ACTION__DETAIL__DIM_LIGHTS__ROSIDL_TYPESUPPORT_FASTRTPS_C_H_


#include <stddef.h>
#include "rosidl_runtime_c/message_type_support_struct.h"
#include "rosidl_typesupport_interface/macros.h"
#include "custom_action_interfaces/msg/rosidl_typesupport_fastrtps_c__visibility_control.h"
#include "custom_action_interfaces/action/detail/dim_lights__struct.h"
#include "fastcdr/Cdr.h"

#ifdef __cplusplus
extern "C"
{
#endif

ROSIDL_TYPESUPPORT_FASTRTPS_C_PUBLIC_custom_action_interfaces
bool cdr_serialize_custom_action_interfaces__action__DimLights_Goal(
  const custom_action_interfaces__action__DimLights_Goal * ros_message,
  eprosima::fastcdr::Cdr & cdr);

ROSIDL_TYPESUPPORT_FASTRTPS_C_PUBLIC_custom_action_interfaces
bool cdr_deserialize_custom_action_interfaces__action__DimLights_Goal(
  eprosima::fastcdr::Cdr &,
  custom_action_interfaces__action__DimLights_Goal * ros_message);

ROSIDL_TYPESUPPORT_FASTRTPS_C_PUBLIC_custom_action_interfaces
size_t get_serialized_size_custom_action_interfaces__action__DimLights_Goal(
  const void * untyped_ros_message,
  size_t current_alignment);

ROSIDL_TYPESUPPORT_FASTRTPS_C_PUBLIC_custom_action_interfaces
size_t max_serialized_size_custom_action_interfaces__action__DimLights_Goal(
  bool & full_bounded,
  bool & is_plain,
  size_t current_alignment);

ROSIDL_TYPESUPPORT_FASTRTPS_C_PUBLIC_custom_action_interfaces
bool cdr_serialize_key_custom_action_interfaces__action__DimLights_Goal(
  const custom_action_interfaces__action__DimLights_Goal * ros_message,
  eprosima::fastcdr::Cdr & cdr);

ROSIDL_TYPESUPPORT_FASTRTPS_C_PUBLIC_custom_action_interfaces
size_t get_serialized_size_key_custom_action_interfaces__action__DimLights_Goal(
  const void * untyped_ros_message,
  size_t current_alignment);

ROSIDL_TYPESUPPORT_FASTRTPS_C_PUBLIC_custom_action_interfaces
size_t max_serialized_size_key_custom_action_interfaces__action__DimLights_Goal(
  bool & full_bounded,
  bool & is_plain,
  size_t current_alignment);

ROSIDL_TYPESUPPORT_FASTRTPS_C_PUBLIC_custom_action_interfaces
const rosidl_message_type_support_t *
ROSIDL_TYPESUPPORT_INTERFACE__MESSAGE_SYMBOL_NAME(rosidl_typesupport_fastrtps_c, custom_action_interfaces, action, DimLights_Goal)();

#ifdef __cplusplus
}
#endif

// already included above
// #include <stddef.h>
// already included above
// #include "rosidl_runtime_c/message_type_support_struct.h"
// already included above
// #include "rosidl_typesupport_interface/macros.h"
// already included above
// #include "custom_action_interfaces/msg/rosidl_typesupport_fastrtps_c__visibility_control.h"
// already included above
// #include "custom_action_interfaces/action/detail/dim_lights__struct.h"
// already included above
// #include "fastcdr/Cdr.h"

#ifdef __cplusplus
extern "C"
{
#endif

ROSIDL_TYPESUPPORT_FASTRTPS_C_PUBLIC_custom_action_interfaces
bool cdr_serialize_custom_action_interfaces__action__DimLights_Result(
  const custom_action_interfaces__action__DimLights_Result * ros_message,
  eprosima::fastcdr::Cdr & cdr);

ROSIDL_TYPESUPPORT_FASTRTPS_C_PUBLIC_custom_action_interfaces
bool cdr_deserialize_custom_action_interfaces__action__DimLights_Result(
  eprosima::fastcdr::Cdr &,
  custom_action_interfaces__action__DimLights_Result * ros_message);

ROSIDL_TYPESUPPORT_FASTRTPS_C_PUBLIC_custom_action_interfaces
size_t get_serialized_size_custom_action_interfaces__action__DimLights_Result(
  const void * untyped_ros_message,
  size_t current_alignment);

ROSIDL_TYPESUPPORT_FASTRTPS_C_PUBLIC_custom_action_interfaces
size_t max_serialized_size_custom_action_interfaces__action__DimLights_Result(
  bool & full_bounded,
  bool & is_plain,
  size_t current_alignment);

ROSIDL_TYPESUPPORT_FASTRTPS_C_PUBLIC_custom_action_interfaces
bool cdr_serialize_key_custom_action_interfaces__action__DimLights_Result(
  const custom_action_interfaces__action__DimLights_Result * ros_message,
  eprosima::fastcdr::Cdr & cdr);

ROSIDL_TYPESUPPORT_FASTRTPS_C_PUBLIC_custom_action_interfaces
size_t get_serialized_size_key_custom_action_interfaces__action__DimLights_Result(
  const void * untyped_ros_message,
  size_t current_alignment);

ROSIDL_TYPESUPPORT_FASTRTPS_C_PUBLIC_custom_action_interfaces
size_t max_serialized_size_key_custom_action_interfaces__action__DimLights_Result(
  bool & full_bounded,
  bool & is_plain,
  size_t current_alignment);

ROSIDL_TYPESUPPORT_FASTRTPS_C_PUBLIC_custom_action_interfaces
const rosidl_message_type_support_t *
ROSIDL_TYPESUPPORT_INTERFACE__MESSAGE_SYMBOL_NAME(rosidl_typesupport_fastrtps_c, custom_action_interfaces, action, DimLights_Result)();

#ifdef __cplusplus
}
#endif

// already included above
// #include <stddef.h>
// already included above
// #include "rosidl_runtime_c/message_type_support_struct.h"
// already included above
// #include "rosidl_typesupport_interface/macros.h"
// already included above
// #include "custom_action_interfaces/msg/rosidl_typesupport_fastrtps_c__visibility_control.h"
// already included above
// #include "custom_action_interfaces/action/detail/dim_lights__struct.h"
// already included above
// #include "fastcdr/Cdr.h"

#ifdef __cplusplus
extern "C"
{
#endif

ROSIDL_TYPESUPPORT_FASTRTPS_C_PUBLIC_custom_action_interfaces
bool cdr_serialize_custom_action_interfaces__action__DimLights_Feedback(
  const custom_action_interfaces__action__DimLights_Feedback * ros_message,
  eprosima::fastcdr::Cdr & cdr);

ROSIDL_TYPESUPPORT_FASTRTPS_C_PUBLIC_custom_action_interfaces
bool cdr_deserialize_custom_action_interfaces__action__DimLights_Feedback(
  eprosima::fastcdr::Cdr &,
  custom_action_interfaces__action__DimLights_Feedback * ros_message);

ROSIDL_TYPESUPPORT_FASTRTPS_C_PUBLIC_custom_action_interfaces
size_t get_serialized_size_custom_action_interfaces__action__DimLights_Feedback(
  const void * untyped_ros_message,
  size_t current_alignment);

ROSIDL_TYPESUPPORT_FASTRTPS_C_PUBLIC_custom_action_interfaces
size_t max_serialized_size_custom_action_interfaces__action__DimLights_Feedback(
  bool & full_bounded,
  bool & is_plain,
  size_t current_alignment);

ROSIDL_TYPESUPPORT_FASTRTPS_C_PUBLIC_custom_action_interfaces
bool cdr_serialize_key_custom_action_interfaces__action__DimLights_Feedback(
  const custom_action_interfaces__action__DimLights_Feedback * ros_message,
  eprosima::fastcdr::Cdr & cdr);

ROSIDL_TYPESUPPORT_FASTRTPS_C_PUBLIC_custom_action_interfaces
size_t get_serialized_size_key_custom_action_interfaces__action__DimLights_Feedback(
  const void * untyped_ros_message,
  size_t current_alignment);

ROSIDL_TYPESUPPORT_FASTRTPS_C_PUBLIC_custom_action_interfaces
size_t max_serialized_size_key_custom_action_interfaces__action__DimLights_Feedback(
  bool & full_bounded,
  bool & is_plain,
  size_t current_alignment);

ROSIDL_TYPESUPPORT_FASTRTPS_C_PUBLIC_custom_action_interfaces
const rosidl_message_type_support_t *
ROSIDL_TYPESUPPORT_INTERFACE__MESSAGE_SYMBOL_NAME(rosidl_typesupport_fastrtps_c, custom_action_interfaces, action, DimLights_Feedback)();

#ifdef __cplusplus
}
#endif

// already included above
// #include <stddef.h>
// already included above
// #include "rosidl_runtime_c/message_type_support_struct.h"
// already included above
// #include "rosidl_typesupport_interface/macros.h"
// already included above
// #include "custom_action_interfaces/msg/rosidl_typesupport_fastrtps_c__visibility_control.h"
// already included above
// #include "custom_action_interfaces/action/detail/dim_lights__struct.h"
// already included above
// #include "fastcdr/Cdr.h"

#ifdef __cplusplus
extern "C"
{
#endif

ROSIDL_TYPESUPPORT_FASTRTPS_C_PUBLIC_custom_action_interfaces
bool cdr_serialize_custom_action_interfaces__action__DimLights_SendGoal_Request(
  const custom_action_interfaces__action__DimLights_SendGoal_Request * ros_message,
  eprosima::fastcdr::Cdr & cdr);

ROSIDL_TYPESUPPORT_FASTRTPS_C_PUBLIC_custom_action_interfaces
bool cdr_deserialize_custom_action_interfaces__action__DimLights_SendGoal_Request(
  eprosima::fastcdr::Cdr &,
  custom_action_interfaces__action__DimLights_SendGoal_Request * ros_message);

ROSIDL_TYPESUPPORT_FASTRTPS_C_PUBLIC_custom_action_interfaces
size_t get_serialized_size_custom_action_interfaces__action__DimLights_SendGoal_Request(
  const void * untyped_ros_message,
  size_t current_alignment);

ROSIDL_TYPESUPPORT_FASTRTPS_C_PUBLIC_custom_action_interfaces
size_t max_serialized_size_custom_action_interfaces__action__DimLights_SendGoal_Request(
  bool & full_bounded,
  bool & is_plain,
  size_t current_alignment);

ROSIDL_TYPESUPPORT_FASTRTPS_C_PUBLIC_custom_action_interfaces
bool cdr_serialize_key_custom_action_interfaces__action__DimLights_SendGoal_Request(
  const custom_action_interfaces__action__DimLights_SendGoal_Request * ros_message,
  eprosima::fastcdr::Cdr & cdr);

ROSIDL_TYPESUPPORT_FASTRTPS_C_PUBLIC_custom_action_interfaces
size_t get_serialized_size_key_custom_action_interfaces__action__DimLights_SendGoal_Request(
  const void * untyped_ros_message,
  size_t current_alignment);

ROSIDL_TYPESUPPORT_FASTRTPS_C_PUBLIC_custom_action_interfaces
size_t max_serialized_size_key_custom_action_interfaces__action__DimLights_SendGoal_Request(
  bool & full_bounded,
  bool & is_plain,
  size_t current_alignment);

ROSIDL_TYPESUPPORT_FASTRTPS_C_PUBLIC_custom_action_interfaces
const rosidl_message_type_support_t *
ROSIDL_TYPESUPPORT_INTERFACE__MESSAGE_SYMBOL_NAME(rosidl_typesupport_fastrtps_c, custom_action_interfaces, action, DimLights_SendGoal_Request)();

#ifdef __cplusplus
}
#endif

// already included above
// #include <stddef.h>
// already included above
// #include "rosidl_runtime_c/message_type_support_struct.h"
// already included above
// #include "rosidl_typesupport_interface/macros.h"
// already included above
// #include "custom_action_interfaces/msg/rosidl_typesupport_fastrtps_c__visibility_control.h"
// already included above
// #include "custom_action_interfaces/action/detail/dim_lights__struct.h"
// already included above
// #include "fastcdr/Cdr.h"

#ifdef __cplusplus
extern "C"
{
#endif

ROSIDL_TYPESUPPORT_FASTRTPS_C_PUBLIC_custom_action_interfaces
bool cdr_serialize_custom_action_interfaces__action__DimLights_SendGoal_Response(
  const custom_action_interfaces__action__DimLights_SendGoal_Response * ros_message,
  eprosima::fastcdr::Cdr & cdr);

ROSIDL_TYPESUPPORT_FASTRTPS_C_PUBLIC_custom_action_interfaces
bool cdr_deserialize_custom_action_interfaces__action__DimLights_SendGoal_Response(
  eprosima::fastcdr::Cdr &,
  custom_action_interfaces__action__DimLights_SendGoal_Response * ros_message);

ROSIDL_TYPESUPPORT_FASTRTPS_C_PUBLIC_custom_action_interfaces
size_t get_serialized_size_custom_action_interfaces__action__DimLights_SendGoal_Response(
  const void * untyped_ros_message,
  size_t current_alignment);

ROSIDL_TYPESUPPORT_FASTRTPS_C_PUBLIC_custom_action_interfaces
size_t max_serialized_size_custom_action_interfaces__action__DimLights_SendGoal_Response(
  bool & full_bounded,
  bool & is_plain,
  size_t current_alignment);

ROSIDL_TYPESUPPORT_FASTRTPS_C_PUBLIC_custom_action_interfaces
bool cdr_serialize_key_custom_action_interfaces__action__DimLights_SendGoal_Response(
  const custom_action_interfaces__action__DimLights_SendGoal_Response * ros_message,
  eprosima::fastcdr::Cdr & cdr);

ROSIDL_TYPESUPPORT_FASTRTPS_C_PUBLIC_custom_action_interfaces
size_t get_serialized_size_key_custom_action_interfaces__action__DimLights_SendGoal_Response(
  const void * untyped_ros_message,
  size_t current_alignment);

ROSIDL_TYPESUPPORT_FASTRTPS_C_PUBLIC_custom_action_interfaces
size_t max_serialized_size_key_custom_action_interfaces__action__DimLights_SendGoal_Response(
  bool & full_bounded,
  bool & is_plain,
  size_t current_alignment);

ROSIDL_TYPESUPPORT_FASTRTPS_C_PUBLIC_custom_action_interfaces
const rosidl_message_type_support_t *
ROSIDL_TYPESUPPORT_INTERFACE__MESSAGE_SYMBOL_NAME(rosidl_typesupport_fastrtps_c, custom_action_interfaces, action, DimLights_SendGoal_Response)();

#ifdef __cplusplus
}
#endif

// already included above
// #include <stddef.h>
// already included above
// #include "rosidl_runtime_c/message_type_support_struct.h"
// already included above
// #include "rosidl_typesupport_interface/macros.h"
// already included above
// #include "custom_action_interfaces/msg/rosidl_typesupport_fastrtps_c__visibility_control.h"
// already included above
// #include "custom_action_interfaces/action/detail/dim_lights__struct.h"
// already included above
// #include "fastcdr/Cdr.h"

#ifdef __cplusplus
extern "C"
{
#endif

ROSIDL_TYPESUPPORT_FASTRTPS_C_PUBLIC_custom_action_interfaces
bool cdr_serialize_custom_action_interfaces__action__DimLights_SendGoal_Event(
  const custom_action_interfaces__action__DimLights_SendGoal_Event * ros_message,
  eprosima::fastcdr::Cdr & cdr);

ROSIDL_TYPESUPPORT_FASTRTPS_C_PUBLIC_custom_action_interfaces
bool cdr_deserialize_custom_action_interfaces__action__DimLights_SendGoal_Event(
  eprosima::fastcdr::Cdr &,
  custom_action_interfaces__action__DimLights_SendGoal_Event * ros_message);

ROSIDL_TYPESUPPORT_FASTRTPS_C_PUBLIC_custom_action_interfaces
size_t get_serialized_size_custom_action_interfaces__action__DimLights_SendGoal_Event(
  const void * untyped_ros_message,
  size_t current_alignment);

ROSIDL_TYPESUPPORT_FASTRTPS_C_PUBLIC_custom_action_interfaces
size_t max_serialized_size_custom_action_interfaces__action__DimLights_SendGoal_Event(
  bool & full_bounded,
  bool & is_plain,
  size_t current_alignment);

ROSIDL_TYPESUPPORT_FASTRTPS_C_PUBLIC_custom_action_interfaces
bool cdr_serialize_key_custom_action_interfaces__action__DimLights_SendGoal_Event(
  const custom_action_interfaces__action__DimLights_SendGoal_Event * ros_message,
  eprosima::fastcdr::Cdr & cdr);

ROSIDL_TYPESUPPORT_FASTRTPS_C_PUBLIC_custom_action_interfaces
size_t get_serialized_size_key_custom_action_interfaces__action__DimLights_SendGoal_Event(
  const void * untyped_ros_message,
  size_t current_alignment);

ROSIDL_TYPESUPPORT_FASTRTPS_C_PUBLIC_custom_action_interfaces
size_t max_serialized_size_key_custom_action_interfaces__action__DimLights_SendGoal_Event(
  bool & full_bounded,
  bool & is_plain,
  size_t current_alignment);

ROSIDL_TYPESUPPORT_FASTRTPS_C_PUBLIC_custom_action_interfaces
const rosidl_message_type_support_t *
ROSIDL_TYPESUPPORT_INTERFACE__MESSAGE_SYMBOL_NAME(rosidl_typesupport_fastrtps_c, custom_action_interfaces, action, DimLights_SendGoal_Event)();

#ifdef __cplusplus
}
#endif

#include "rosidl_runtime_c/service_type_support_struct.h"
// already included above
// #include "rosidl_typesupport_interface/macros.h"
// already included above
// #include "custom_action_interfaces/msg/rosidl_typesupport_fastrtps_c__visibility_control.h"

#ifdef __cplusplus
extern "C"
{
#endif

ROSIDL_TYPESUPPORT_FASTRTPS_C_PUBLIC_custom_action_interfaces
const rosidl_service_type_support_t *
ROSIDL_TYPESUPPORT_INTERFACE__SERVICE_SYMBOL_NAME(rosidl_typesupport_fastrtps_c, custom_action_interfaces, action, DimLights_SendGoal)();

#ifdef __cplusplus
}
#endif

// already included above
// #include <stddef.h>
// already included above
// #include "rosidl_runtime_c/message_type_support_struct.h"
// already included above
// #include "rosidl_typesupport_interface/macros.h"
// already included above
// #include "custom_action_interfaces/msg/rosidl_typesupport_fastrtps_c__visibility_control.h"
// already included above
// #include "custom_action_interfaces/action/detail/dim_lights__struct.h"
// already included above
// #include "fastcdr/Cdr.h"

#ifdef __cplusplus
extern "C"
{
#endif

ROSIDL_TYPESUPPORT_FASTRTPS_C_PUBLIC_custom_action_interfaces
bool cdr_serialize_custom_action_interfaces__action__DimLights_GetResult_Request(
  const custom_action_interfaces__action__DimLights_GetResult_Request * ros_message,
  eprosima::fastcdr::Cdr & cdr);

ROSIDL_TYPESUPPORT_FASTRTPS_C_PUBLIC_custom_action_interfaces
bool cdr_deserialize_custom_action_interfaces__action__DimLights_GetResult_Request(
  eprosima::fastcdr::Cdr &,
  custom_action_interfaces__action__DimLights_GetResult_Request * ros_message);

ROSIDL_TYPESUPPORT_FASTRTPS_C_PUBLIC_custom_action_interfaces
size_t get_serialized_size_custom_action_interfaces__action__DimLights_GetResult_Request(
  const void * untyped_ros_message,
  size_t current_alignment);

ROSIDL_TYPESUPPORT_FASTRTPS_C_PUBLIC_custom_action_interfaces
size_t max_serialized_size_custom_action_interfaces__action__DimLights_GetResult_Request(
  bool & full_bounded,
  bool & is_plain,
  size_t current_alignment);

ROSIDL_TYPESUPPORT_FASTRTPS_C_PUBLIC_custom_action_interfaces
bool cdr_serialize_key_custom_action_interfaces__action__DimLights_GetResult_Request(
  const custom_action_interfaces__action__DimLights_GetResult_Request * ros_message,
  eprosima::fastcdr::Cdr & cdr);

ROSIDL_TYPESUPPORT_FASTRTPS_C_PUBLIC_custom_action_interfaces
size_t get_serialized_size_key_custom_action_interfaces__action__DimLights_GetResult_Request(
  const void * untyped_ros_message,
  size_t current_alignment);

ROSIDL_TYPESUPPORT_FASTRTPS_C_PUBLIC_custom_action_interfaces
size_t max_serialized_size_key_custom_action_interfaces__action__DimLights_GetResult_Request(
  bool & full_bounded,
  bool & is_plain,
  size_t current_alignment);

ROSIDL_TYPESUPPORT_FASTRTPS_C_PUBLIC_custom_action_interfaces
const rosidl_message_type_support_t *
ROSIDL_TYPESUPPORT_INTERFACE__MESSAGE_SYMBOL_NAME(rosidl_typesupport_fastrtps_c, custom_action_interfaces, action, DimLights_GetResult_Request)();

#ifdef __cplusplus
}
#endif

// already included above
// #include <stddef.h>
// already included above
// #include "rosidl_runtime_c/message_type_support_struct.h"
// already included above
// #include "rosidl_typesupport_interface/macros.h"
// already included above
// #include "custom_action_interfaces/msg/rosidl_typesupport_fastrtps_c__visibility_control.h"
// already included above
// #include "custom_action_interfaces/action/detail/dim_lights__struct.h"
// already included above
// #include "fastcdr/Cdr.h"

#ifdef __cplusplus
extern "C"
{
#endif

ROSIDL_TYPESUPPORT_FASTRTPS_C_PUBLIC_custom_action_interfaces
bool cdr_serialize_custom_action_interfaces__action__DimLights_GetResult_Response(
  const custom_action_interfaces__action__DimLights_GetResult_Response * ros_message,
  eprosima::fastcdr::Cdr & cdr);

ROSIDL_TYPESUPPORT_FASTRTPS_C_PUBLIC_custom_action_interfaces
bool cdr_deserialize_custom_action_interfaces__action__DimLights_GetResult_Response(
  eprosima::fastcdr::Cdr &,
  custom_action_interfaces__action__DimLights_GetResult_Response * ros_message);

ROSIDL_TYPESUPPORT_FASTRTPS_C_PUBLIC_custom_action_interfaces
size_t get_serialized_size_custom_action_interfaces__action__DimLights_GetResult_Response(
  const void * untyped_ros_message,
  size_t current_alignment);

ROSIDL_TYPESUPPORT_FASTRTPS_C_PUBLIC_custom_action_interfaces
size_t max_serialized_size_custom_action_interfaces__action__DimLights_GetResult_Response(
  bool & full_bounded,
  bool & is_plain,
  size_t current_alignment);

ROSIDL_TYPESUPPORT_FASTRTPS_C_PUBLIC_custom_action_interfaces
bool cdr_serialize_key_custom_action_interfaces__action__DimLights_GetResult_Response(
  const custom_action_interfaces__action__DimLights_GetResult_Response * ros_message,
  eprosima::fastcdr::Cdr & cdr);

ROSIDL_TYPESUPPORT_FASTRTPS_C_PUBLIC_custom_action_interfaces
size_t get_serialized_size_key_custom_action_interfaces__action__DimLights_GetResult_Response(
  const void * untyped_ros_message,
  size_t current_alignment);

ROSIDL_TYPESUPPORT_FASTRTPS_C_PUBLIC_custom_action_interfaces
size_t max_serialized_size_key_custom_action_interfaces__action__DimLights_GetResult_Response(
  bool & full_bounded,
  bool & is_plain,
  size_t current_alignment);

ROSIDL_TYPESUPPORT_FASTRTPS_C_PUBLIC_custom_action_interfaces
const rosidl_message_type_support_t *
ROSIDL_TYPESUPPORT_INTERFACE__MESSAGE_SYMBOL_NAME(rosidl_typesupport_fastrtps_c, custom_action_interfaces, action, DimLights_GetResult_Response)();

#ifdef __cplusplus
}
#endif

// already included above
// #include <stddef.h>
// already included above
// #include "rosidl_runtime_c/message_type_support_struct.h"
// already included above
// #include "rosidl_typesupport_interface/macros.h"
// already included above
// #include "custom_action_interfaces/msg/rosidl_typesupport_fastrtps_c__visibility_control.h"
// already included above
// #include "custom_action_interfaces/action/detail/dim_lights__struct.h"
// already included above
// #include "fastcdr/Cdr.h"

#ifdef __cplusplus
extern "C"
{
#endif

ROSIDL_TYPESUPPORT_FASTRTPS_C_PUBLIC_custom_action_interfaces
bool cdr_serialize_custom_action_interfaces__action__DimLights_GetResult_Event(
  const custom_action_interfaces__action__DimLights_GetResult_Event * ros_message,
  eprosima::fastcdr::Cdr & cdr);

ROSIDL_TYPESUPPORT_FASTRTPS_C_PUBLIC_custom_action_interfaces
bool cdr_deserialize_custom_action_interfaces__action__DimLights_GetResult_Event(
  eprosima::fastcdr::Cdr &,
  custom_action_interfaces__action__DimLights_GetResult_Event * ros_message);

ROSIDL_TYPESUPPORT_FASTRTPS_C_PUBLIC_custom_action_interfaces
size_t get_serialized_size_custom_action_interfaces__action__DimLights_GetResult_Event(
  const void * untyped_ros_message,
  size_t current_alignment);

ROSIDL_TYPESUPPORT_FASTRTPS_C_PUBLIC_custom_action_interfaces
size_t max_serialized_size_custom_action_interfaces__action__DimLights_GetResult_Event(
  bool & full_bounded,
  bool & is_plain,
  size_t current_alignment);

ROSIDL_TYPESUPPORT_FASTRTPS_C_PUBLIC_custom_action_interfaces
bool cdr_serialize_key_custom_action_interfaces__action__DimLights_GetResult_Event(
  const custom_action_interfaces__action__DimLights_GetResult_Event * ros_message,
  eprosima::fastcdr::Cdr & cdr);

ROSIDL_TYPESUPPORT_FASTRTPS_C_PUBLIC_custom_action_interfaces
size_t get_serialized_size_key_custom_action_interfaces__action__DimLights_GetResult_Event(
  const void * untyped_ros_message,
  size_t current_alignment);

ROSIDL_TYPESUPPORT_FASTRTPS_C_PUBLIC_custom_action_interfaces
size_t max_serialized_size_key_custom_action_interfaces__action__DimLights_GetResult_Event(
  bool & full_bounded,
  bool & is_plain,
  size_t current_alignment);

ROSIDL_TYPESUPPORT_FASTRTPS_C_PUBLIC_custom_action_interfaces
const rosidl_message_type_support_t *
ROSIDL_TYPESUPPORT_INTERFACE__MESSAGE_SYMBOL_NAME(rosidl_typesupport_fastrtps_c, custom_action_interfaces, action, DimLights_GetResult_Event)();

#ifdef __cplusplus
}
#endif

// already included above
// #include "rosidl_runtime_c/service_type_support_struct.h"
// already included above
// #include "rosidl_typesupport_interface/macros.h"
// already included above
// #include "custom_action_interfaces/msg/rosidl_typesupport_fastrtps_c__visibility_control.h"

#ifdef __cplusplus
extern "C"
{
#endif

ROSIDL_TYPESUPPORT_FASTRTPS_C_PUBLIC_custom_action_interfaces
const rosidl_service_type_support_t *
ROSIDL_TYPESUPPORT_INTERFACE__SERVICE_SYMBOL_NAME(rosidl_typesupport_fastrtps_c, custom_action_interfaces, action, DimLights_GetResult)();

#ifdef __cplusplus
}
#endif

// already included above
// #include <stddef.h>
// already included above
// #include "rosidl_runtime_c/message_type_support_struct.h"
// already included above
// #include "rosidl_typesupport_interface/macros.h"
// already included above
// #include "custom_action_interfaces/msg/rosidl_typesupport_fastrtps_c__visibility_control.h"
// already included above
// #include "custom_action_interfaces/action/detail/dim_lights__struct.h"
// already included above
// #include "fastcdr/Cdr.h"

#ifdef __cplusplus
extern "C"
{
#endif

ROSIDL_TYPESUPPORT_FASTRTPS_C_PUBLIC_custom_action_interfaces
bool cdr_serialize_custom_action_interfaces__action__DimLights_FeedbackMessage(
  const custom_action_interfaces__action__DimLights_FeedbackMessage * ros_message,
  eprosima::fastcdr::Cdr & cdr);

ROSIDL_TYPESUPPORT_FASTRTPS_C_PUBLIC_custom_action_interfaces
bool cdr_deserialize_custom_action_interfaces__action__DimLights_FeedbackMessage(
  eprosima::fastcdr::Cdr &,
  custom_action_interfaces__action__DimLights_FeedbackMessage * ros_message);

ROSIDL_TYPESUPPORT_FASTRTPS_C_PUBLIC_custom_action_interfaces
size_t get_serialized_size_custom_action_interfaces__action__DimLights_FeedbackMessage(
  const void * untyped_ros_message,
  size_t current_alignment);

ROSIDL_TYPESUPPORT_FASTRTPS_C_PUBLIC_custom_action_interfaces
size_t max_serialized_size_custom_action_interfaces__action__DimLights_FeedbackMessage(
  bool & full_bounded,
  bool & is_plain,
  size_t current_alignment);

ROSIDL_TYPESUPPORT_FASTRTPS_C_PUBLIC_custom_action_interfaces
bool cdr_serialize_key_custom_action_interfaces__action__DimLights_FeedbackMessage(
  const custom_action_interfaces__action__DimLights_FeedbackMessage * ros_message,
  eprosima::fastcdr::Cdr & cdr);

ROSIDL_TYPESUPPORT_FASTRTPS_C_PUBLIC_custom_action_interfaces
size_t get_serialized_size_key_custom_action_interfaces__action__DimLights_FeedbackMessage(
  const void * untyped_ros_message,
  size_t current_alignment);

ROSIDL_TYPESUPPORT_FASTRTPS_C_PUBLIC_custom_action_interfaces
size_t max_serialized_size_key_custom_action_interfaces__action__DimLights_FeedbackMessage(
  bool & full_bounded,
  bool & is_plain,
  size_t current_alignment);

ROSIDL_TYPESUPPORT_FASTRTPS_C_PUBLIC_custom_action_interfaces
const rosidl_message_type_support_t *
ROSIDL_TYPESUPPORT_INTERFACE__MESSAGE_SYMBOL_NAME(rosidl_typesupport_fastrtps_c, custom_action_interfaces, action, DimLights_FeedbackMessage)();

#ifdef __cplusplus
}
#endif

#endif  // CUSTOM_ACTION_INTERFACES__ACTION__DETAIL__DIM_LIGHTS__ROSIDL_TYPESUPPORT_FASTRTPS_C_H_
