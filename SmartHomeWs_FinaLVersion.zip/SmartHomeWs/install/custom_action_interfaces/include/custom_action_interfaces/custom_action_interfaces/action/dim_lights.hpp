// generated from rosidl_generator_cpp/resource/idl.hpp.em
// generated code does not contain a copyright notice

#ifndef CUSTOM_ACTION_INTERFACES__ACTION__DIM_LIGHTS_HPP_
#define CUSTOM_ACTION_INTERFACES__ACTION__DIM_LIGHTS_HPP_

#include "custom_action_interfaces/action/detail/dim_lights__struct.hpp"
#include "custom_action_interfaces/action/detail/dim_lights__builder.hpp"
#include "custom_action_interfaces/action/detail/dim_lights__traits.hpp"
#include "custom_action_interfaces/action/detail/dim_lights__type_support.hpp"

#endif  // CUSTOM_ACTION_INTERFACES__ACTION__DIM_LIGHTS_HPP_
