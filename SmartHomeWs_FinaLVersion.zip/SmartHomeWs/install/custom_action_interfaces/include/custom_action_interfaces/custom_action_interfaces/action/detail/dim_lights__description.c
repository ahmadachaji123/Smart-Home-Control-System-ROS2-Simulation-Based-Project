// generated from rosidl_generator_c/resource/idl__description.c.em
// with input from custom_action_interfaces:action/DimLights.idl
// generated code does not contain a copyright notice

#include "custom_action_interfaces/action/detail/dim_lights__functions.h"

ROSIDL_GENERATOR_C_PUBLIC_custom_action_interfaces
const rosidl_type_hash_t *
custom_action_interfaces__action__DimLights__get_type_hash(
  const rosidl_action_type_support_t * type_support)
{
  (void)type_support;
  static rosidl_type_hash_t hash = {1, {
      0x1c, 0x12, 0x1f, 0x90, 0x4a, 0x24, 0x54, 0xf8,
      0x8e, 0x07, 0xe2, 0x05, 0x0e, 0x6e, 0x03, 0x70,
      0xc2, 0x58, 0xd8, 0xca, 0x0f, 0x31, 0x3b, 0x7f,
      0xf9, 0x85, 0x08, 0xa7, 0xfc, 0x9b, 0xfb, 0x4d,
    }};
  return &hash;
}

ROSIDL_GENERATOR_C_PUBLIC_custom_action_interfaces
const rosidl_type_hash_t *
custom_action_interfaces__action__DimLights_Goal__get_type_hash(
  const rosidl_message_type_support_t * type_support)
{
  (void)type_support;
  static rosidl_type_hash_t hash = {1, {
      0x63, 0x9d, 0x20, 0xd9, 0xd1, 0x0b, 0xe7, 0x12,
      0xae, 0xa3, 0xbd, 0xd3, 0x20, 0x8e, 0xe9, 0x0a,
      0x2c, 0x96, 0x0b, 0x08, 0x97, 0x26, 0xbe, 0xd7,
      0x60, 0xf6, 0x2a, 0x1f, 0x48, 0xd4, 0xa6, 0xb9,
    }};
  return &hash;
}

ROSIDL_GENERATOR_C_PUBLIC_custom_action_interfaces
const rosidl_type_hash_t *
custom_action_interfaces__action__DimLights_Result__get_type_hash(
  const rosidl_message_type_support_t * type_support)
{
  (void)type_support;
  static rosidl_type_hash_t hash = {1, {
      0xb3, 0x3e, 0xef, 0x92, 0x51, 0x5a, 0x15, 0x94,
      0x8b, 0x03, 0x05, 0xce, 0x6b, 0x41, 0xe7, 0x5c,
      0xff, 0x98, 0x08, 0xbd, 0xd4, 0x1e, 0x92, 0x46,
      0xab, 0x99, 0xb6, 0xf0, 0xbe, 0x1d, 0x26, 0x68,
    }};
  return &hash;
}

ROSIDL_GENERATOR_C_PUBLIC_custom_action_interfaces
const rosidl_type_hash_t *
custom_action_interfaces__action__DimLights_Feedback__get_type_hash(
  const rosidl_message_type_support_t * type_support)
{
  (void)type_support;
  static rosidl_type_hash_t hash = {1, {
      0xa8, 0xe4, 0x79, 0x7a, 0x42, 0x5c, 0xf3, 0x79,
      0x9d, 0xfe, 0x46, 0xc7, 0xc6, 0x61, 0xb0, 0x94,
      0xab, 0xea, 0x60, 0x3f, 0xb5, 0xa5, 0xfe, 0xe9,
      0x38, 0xaa, 0x21, 0x81, 0x3f, 0xfe, 0x25, 0x96,
    }};
  return &hash;
}

ROSIDL_GENERATOR_C_PUBLIC_custom_action_interfaces
const rosidl_type_hash_t *
custom_action_interfaces__action__DimLights_SendGoal__get_type_hash(
  const rosidl_service_type_support_t * type_support)
{
  (void)type_support;
  static rosidl_type_hash_t hash = {1, {
      0xd3, 0x9d, 0x25, 0x1a, 0xc1, 0x9a, 0x50, 0xd4,
      0xc4, 0xfd, 0xcd, 0x58, 0xb2, 0x1f, 0xb8, 0x04,
      0xd6, 0xfb, 0xec, 0x28, 0xb5, 0x36, 0x08, 0x94,
      0xf7, 0xf0, 0xf0, 0xbe, 0xfe, 0x16, 0x46, 0x0e,
    }};
  return &hash;
}

ROSIDL_GENERATOR_C_PUBLIC_custom_action_interfaces
const rosidl_type_hash_t *
custom_action_interfaces__action__DimLights_SendGoal_Request__get_type_hash(
  const rosidl_message_type_support_t * type_support)
{
  (void)type_support;
  static rosidl_type_hash_t hash = {1, {
      0x39, 0xc4, 0x01, 0x85, 0x8b, 0x0c, 0x7c, 0x8c,
      0x70, 0x65, 0xb6, 0x4c, 0xc7, 0x89, 0x9f, 0xe9,
      0x09, 0xf1, 0x86, 0x5f, 0xc4, 0x5a, 0x5c, 0x9b,
      0x9b, 0x69, 0xa7, 0x11, 0x96, 0x25, 0xed, 0x31,
    }};
  return &hash;
}

ROSIDL_GENERATOR_C_PUBLIC_custom_action_interfaces
const rosidl_type_hash_t *
custom_action_interfaces__action__DimLights_SendGoal_Response__get_type_hash(
  const rosidl_message_type_support_t * type_support)
{
  (void)type_support;
  static rosidl_type_hash_t hash = {1, {
      0x80, 0x17, 0xa6, 0x44, 0x7a, 0x9e, 0x4b, 0xfa,
      0x7a, 0xf6, 0xd3, 0x3b, 0xe1, 0x05, 0xc8, 0xc5,
      0x33, 0xda, 0x82, 0xcb, 0xb5, 0x71, 0x0d, 0x28,
      0xd6, 0x2b, 0x5e, 0x13, 0x06, 0xeb, 0xcc, 0x63,
    }};
  return &hash;
}

ROSIDL_GENERATOR_C_PUBLIC_custom_action_interfaces
const rosidl_type_hash_t *
custom_action_interfaces__action__DimLights_SendGoal_Event__get_type_hash(
  const rosidl_message_type_support_t * type_support)
{
  (void)type_support;
  static rosidl_type_hash_t hash = {1, {
      0xe7, 0xe6, 0xae, 0x63, 0x83, 0x44, 0xfd, 0x0d,
      0x65, 0xfe, 0x1d, 0xd7, 0x14, 0xe0, 0x36, 0x3c,
      0x58, 0xa5, 0xd6, 0x1f, 0x79, 0x01, 0xc9, 0xef,
      0xa4, 0xd0, 0x7e, 0x2c, 0x37, 0x0d, 0x7b, 0xdd,
    }};
  return &hash;
}

ROSIDL_GENERATOR_C_PUBLIC_custom_action_interfaces
const rosidl_type_hash_t *
custom_action_interfaces__action__DimLights_GetResult__get_type_hash(
  const rosidl_service_type_support_t * type_support)
{
  (void)type_support;
  static rosidl_type_hash_t hash = {1, {
      0x6d, 0xa7, 0x61, 0xb3, 0x56, 0x5e, 0xc8, 0xfe,
      0xc6, 0x29, 0x4e, 0x12, 0xf3, 0x09, 0xe1, 0xee,
      0x6c, 0x97, 0xab, 0xa9, 0x59, 0xf3, 0x94, 0x4b,
      0x0a, 0xd6, 0x57, 0xd3, 0xa0, 0xc8, 0x62, 0xb8,
    }};
  return &hash;
}

ROSIDL_GENERATOR_C_PUBLIC_custom_action_interfaces
const rosidl_type_hash_t *
custom_action_interfaces__action__DimLights_GetResult_Request__get_type_hash(
  const rosidl_message_type_support_t * type_support)
{
  (void)type_support;
  static rosidl_type_hash_t hash = {1, {
      0xff, 0x13, 0x78, 0x43, 0x3a, 0x72, 0x5a, 0xf5,
      0x81, 0xbc, 0x0a, 0x3a, 0x30, 0x99, 0x8a, 0xa4,
      0xb8, 0xd1, 0x67, 0xea, 0xc8, 0x14, 0xff, 0x06,
      0xee, 0x3a, 0xcd, 0x95, 0xad, 0x55, 0xef, 0xeb,
    }};
  return &hash;
}

ROSIDL_GENERATOR_C_PUBLIC_custom_action_interfaces
const rosidl_type_hash_t *
custom_action_interfaces__action__DimLights_GetResult_Response__get_type_hash(
  const rosidl_message_type_support_t * type_support)
{
  (void)type_support;
  static rosidl_type_hash_t hash = {1, {
      0x4e, 0xdf, 0xaf, 0xa7, 0xd4, 0x5f, 0xb9, 0x1c,
      0x22, 0x7e, 0x3c, 0x1e, 0x97, 0x3f, 0xb3, 0xeb,
      0x2b, 0xb3, 0xd0, 0x9c, 0xd0, 0x0a, 0x7b, 0xde,
      0xea, 0xd2, 0x0a, 0x1f, 0x25, 0x75, 0x90, 0x9e,
    }};
  return &hash;
}

ROSIDL_GENERATOR_C_PUBLIC_custom_action_interfaces
const rosidl_type_hash_t *
custom_action_interfaces__action__DimLights_GetResult_Event__get_type_hash(
  const rosidl_message_type_support_t * type_support)
{
  (void)type_support;
  static rosidl_type_hash_t hash = {1, {
      0x95, 0x45, 0x52, 0x99, 0x9b, 0xb5, 0x7a, 0xfd,
      0xc6, 0x43, 0x05, 0x02, 0xbb, 0x15, 0xb6, 0xde,
      0x93, 0xcf, 0xda, 0x20, 0x71, 0xa3, 0xf4, 0x58,
      0x2f, 0x63, 0x44, 0xf6, 0x0d, 0xdc, 0xc1, 0xbb,
    }};
  return &hash;
}

ROSIDL_GENERATOR_C_PUBLIC_custom_action_interfaces
const rosidl_type_hash_t *
custom_action_interfaces__action__DimLights_FeedbackMessage__get_type_hash(
  const rosidl_message_type_support_t * type_support)
{
  (void)type_support;
  static rosidl_type_hash_t hash = {1, {
      0x81, 0xc4, 0x88, 0x00, 0x18, 0xa3, 0x95, 0xe7,
      0xe3, 0x78, 0x93, 0xff, 0x21, 0xb6, 0xe4, 0xe3,
      0xe0, 0x01, 0xcb, 0x0d, 0xb1, 0x05, 0xef, 0x48,
      0x4b, 0xc0, 0xec, 0xf5, 0x30, 0x4a, 0x9c, 0xe1,
    }};
  return &hash;
}

#include <assert.h>
#include <string.h>

// Include directives for referenced types
#include "service_msgs/msg/detail/service_event_info__functions.h"
#include "builtin_interfaces/msg/detail/time__functions.h"
#include "unique_identifier_msgs/msg/detail/uuid__functions.h"

// Hashes for external referenced types
#ifndef NDEBUG
static const rosidl_type_hash_t builtin_interfaces__msg__Time__EXPECTED_HASH = {1, {
    0xb1, 0x06, 0x23, 0x5e, 0x25, 0xa4, 0xc5, 0xed,
    0x35, 0x09, 0x8a, 0xa0, 0xa6, 0x1a, 0x3e, 0xe9,
    0xc9, 0xb1, 0x8d, 0x19, 0x7f, 0x39, 0x8b, 0x0e,
    0x42, 0x06, 0xce, 0xa9, 0xac, 0xf9, 0xc1, 0x97,
  }};
static const rosidl_type_hash_t service_msgs__msg__ServiceEventInfo__EXPECTED_HASH = {1, {
    0x41, 0xbc, 0xbb, 0xe0, 0x7a, 0x75, 0xc9, 0xb5,
    0x2b, 0xc9, 0x6b, 0xfd, 0x5c, 0x24, 0xd7, 0xf0,
    0xfc, 0x0a, 0x08, 0xc0, 0xcb, 0x79, 0x21, 0xb3,
    0x37, 0x3c, 0x57, 0x32, 0x34, 0x5a, 0x6f, 0x45,
  }};
static const rosidl_type_hash_t unique_identifier_msgs__msg__UUID__EXPECTED_HASH = {1, {
    0x1b, 0x8e, 0x8a, 0xca, 0x95, 0x8c, 0xbe, 0xa2,
    0x8f, 0xe6, 0xef, 0x60, 0xbf, 0x6c, 0x19, 0xb6,
    0x83, 0xc9, 0x7a, 0x9e, 0xf6, 0x0b, 0xb3, 0x47,
    0x52, 0x06, 0x7d, 0x0f, 0x2f, 0x7a, 0xb4, 0x37,
  }};
#endif

static char custom_action_interfaces__action__DimLights__TYPE_NAME[] = "custom_action_interfaces/action/DimLights";
static char builtin_interfaces__msg__Time__TYPE_NAME[] = "builtin_interfaces/msg/Time";
static char custom_action_interfaces__action__DimLights_Feedback__TYPE_NAME[] = "custom_action_interfaces/action/DimLights_Feedback";
static char custom_action_interfaces__action__DimLights_FeedbackMessage__TYPE_NAME[] = "custom_action_interfaces/action/DimLights_FeedbackMessage";
static char custom_action_interfaces__action__DimLights_GetResult__TYPE_NAME[] = "custom_action_interfaces/action/DimLights_GetResult";
static char custom_action_interfaces__action__DimLights_GetResult_Event__TYPE_NAME[] = "custom_action_interfaces/action/DimLights_GetResult_Event";
static char custom_action_interfaces__action__DimLights_GetResult_Request__TYPE_NAME[] = "custom_action_interfaces/action/DimLights_GetResult_Request";
static char custom_action_interfaces__action__DimLights_GetResult_Response__TYPE_NAME[] = "custom_action_interfaces/action/DimLights_GetResult_Response";
static char custom_action_interfaces__action__DimLights_Goal__TYPE_NAME[] = "custom_action_interfaces/action/DimLights_Goal";
static char custom_action_interfaces__action__DimLights_Result__TYPE_NAME[] = "custom_action_interfaces/action/DimLights_Result";
static char custom_action_interfaces__action__DimLights_SendGoal__TYPE_NAME[] = "custom_action_interfaces/action/DimLights_SendGoal";
static char custom_action_interfaces__action__DimLights_SendGoal_Event__TYPE_NAME[] = "custom_action_interfaces/action/DimLights_SendGoal_Event";
static char custom_action_interfaces__action__DimLights_SendGoal_Request__TYPE_NAME[] = "custom_action_interfaces/action/DimLights_SendGoal_Request";
static char custom_action_interfaces__action__DimLights_SendGoal_Response__TYPE_NAME[] = "custom_action_interfaces/action/DimLights_SendGoal_Response";
static char service_msgs__msg__ServiceEventInfo__TYPE_NAME[] = "service_msgs/msg/ServiceEventInfo";
static char unique_identifier_msgs__msg__UUID__TYPE_NAME[] = "unique_identifier_msgs/msg/UUID";

// Define type names, field names, and default values
static char custom_action_interfaces__action__DimLights__FIELD_NAME__goal[] = "goal";
static char custom_action_interfaces__action__DimLights__FIELD_NAME__result[] = "result";
static char custom_action_interfaces__action__DimLights__FIELD_NAME__feedback[] = "feedback";
static char custom_action_interfaces__action__DimLights__FIELD_NAME__send_goal_service[] = "send_goal_service";
static char custom_action_interfaces__action__DimLights__FIELD_NAME__get_result_service[] = "get_result_service";
static char custom_action_interfaces__action__DimLights__FIELD_NAME__feedback_message[] = "feedback_message";

static rosidl_runtime_c__type_description__Field custom_action_interfaces__action__DimLights__FIELDS[] = {
  {
    {custom_action_interfaces__action__DimLights__FIELD_NAME__goal, 4, 4},
    {
      rosidl_runtime_c__type_description__FieldType__FIELD_TYPE_NESTED_TYPE,
      0,
      0,
      {custom_action_interfaces__action__DimLights_Goal__TYPE_NAME, 46, 46},
    },
    {NULL, 0, 0},
  },
  {
    {custom_action_interfaces__action__DimLights__FIELD_NAME__result, 6, 6},
    {
      rosidl_runtime_c__type_description__FieldType__FIELD_TYPE_NESTED_TYPE,
      0,
      0,
      {custom_action_interfaces__action__DimLights_Result__TYPE_NAME, 48, 48},
    },
    {NULL, 0, 0},
  },
  {
    {custom_action_interfaces__action__DimLights__FIELD_NAME__feedback, 8, 8},
    {
      rosidl_runtime_c__type_description__FieldType__FIELD_TYPE_NESTED_TYPE,
      0,
      0,
      {custom_action_interfaces__action__DimLights_Feedback__TYPE_NAME, 50, 50},
    },
    {NULL, 0, 0},
  },
  {
    {custom_action_interfaces__action__DimLights__FIELD_NAME__send_goal_service, 17, 17},
    {
      rosidl_runtime_c__type_description__FieldType__FIELD_TYPE_NESTED_TYPE,
      0,
      0,
      {custom_action_interfaces__action__DimLights_SendGoal__TYPE_NAME, 50, 50},
    },
    {NULL, 0, 0},
  },
  {
    {custom_action_interfaces__action__DimLights__FIELD_NAME__get_result_service, 18, 18},
    {
      rosidl_runtime_c__type_description__FieldType__FIELD_TYPE_NESTED_TYPE,
      0,
      0,
      {custom_action_interfaces__action__DimLights_GetResult__TYPE_NAME, 51, 51},
    },
    {NULL, 0, 0},
  },
  {
    {custom_action_interfaces__action__DimLights__FIELD_NAME__feedback_message, 16, 16},
    {
      rosidl_runtime_c__type_description__FieldType__FIELD_TYPE_NESTED_TYPE,
      0,
      0,
      {custom_action_interfaces__action__DimLights_FeedbackMessage__TYPE_NAME, 57, 57},
    },
    {NULL, 0, 0},
  },
};

static rosidl_runtime_c__type_description__IndividualTypeDescription custom_action_interfaces__action__DimLights__REFERENCED_TYPE_DESCRIPTIONS[] = {
  {
    {builtin_interfaces__msg__Time__TYPE_NAME, 27, 27},
    {NULL, 0, 0},
  },
  {
    {custom_action_interfaces__action__DimLights_Feedback__TYPE_NAME, 50, 50},
    {NULL, 0, 0},
  },
  {
    {custom_action_interfaces__action__DimLights_FeedbackMessage__TYPE_NAME, 57, 57},
    {NULL, 0, 0},
  },
  {
    {custom_action_interfaces__action__DimLights_GetResult__TYPE_NAME, 51, 51},
    {NULL, 0, 0},
  },
  {
    {custom_action_interfaces__action__DimLights_GetResult_Event__TYPE_NAME, 57, 57},
    {NULL, 0, 0},
  },
  {
    {custom_action_interfaces__action__DimLights_GetResult_Request__TYPE_NAME, 59, 59},
    {NULL, 0, 0},
  },
  {
    {custom_action_interfaces__action__DimLights_GetResult_Response__TYPE_NAME, 60, 60},
    {NULL, 0, 0},
  },
  {
    {custom_action_interfaces__action__DimLights_Goal__TYPE_NAME, 46, 46},
    {NULL, 0, 0},
  },
  {
    {custom_action_interfaces__action__DimLights_Result__TYPE_NAME, 48, 48},
    {NULL, 0, 0},
  },
  {
    {custom_action_interfaces__action__DimLights_SendGoal__TYPE_NAME, 50, 50},
    {NULL, 0, 0},
  },
  {
    {custom_action_interfaces__action__DimLights_SendGoal_Event__TYPE_NAME, 56, 56},
    {NULL, 0, 0},
  },
  {
    {custom_action_interfaces__action__DimLights_SendGoal_Request__TYPE_NAME, 58, 58},
    {NULL, 0, 0},
  },
  {
    {custom_action_interfaces__action__DimLights_SendGoal_Response__TYPE_NAME, 59, 59},
    {NULL, 0, 0},
  },
  {
    {service_msgs__msg__ServiceEventInfo__TYPE_NAME, 33, 33},
    {NULL, 0, 0},
  },
  {
    {unique_identifier_msgs__msg__UUID__TYPE_NAME, 31, 31},
    {NULL, 0, 0},
  },
};

const rosidl_runtime_c__type_description__TypeDescription *
custom_action_interfaces__action__DimLights__get_type_description(
  const rosidl_action_type_support_t * type_support)
{
  (void)type_support;
  static bool constructed = false;
  static const rosidl_runtime_c__type_description__TypeDescription description = {
    {
      {custom_action_interfaces__action__DimLights__TYPE_NAME, 41, 41},
      {custom_action_interfaces__action__DimLights__FIELDS, 6, 6},
    },
    {custom_action_interfaces__action__DimLights__REFERENCED_TYPE_DESCRIPTIONS, 15, 15},
  };
  if (!constructed) {
    assert(0 == memcmp(&builtin_interfaces__msg__Time__EXPECTED_HASH, builtin_interfaces__msg__Time__get_type_hash(NULL), sizeof(rosidl_type_hash_t)));
    description.referenced_type_descriptions.data[0].fields = builtin_interfaces__msg__Time__get_type_description(NULL)->type_description.fields;
    description.referenced_type_descriptions.data[1].fields = custom_action_interfaces__action__DimLights_Feedback__get_type_description(NULL)->type_description.fields;
    description.referenced_type_descriptions.data[2].fields = custom_action_interfaces__action__DimLights_FeedbackMessage__get_type_description(NULL)->type_description.fields;
    description.referenced_type_descriptions.data[3].fields = custom_action_interfaces__action__DimLights_GetResult__get_type_description(NULL)->type_description.fields;
    description.referenced_type_descriptions.data[4].fields = custom_action_interfaces__action__DimLights_GetResult_Event__get_type_description(NULL)->type_description.fields;
    description.referenced_type_descriptions.data[5].fields = custom_action_interfaces__action__DimLights_GetResult_Request__get_type_description(NULL)->type_description.fields;
    description.referenced_type_descriptions.data[6].fields = custom_action_interfaces__action__DimLights_GetResult_Response__get_type_description(NULL)->type_description.fields;
    description.referenced_type_descriptions.data[7].fields = custom_action_interfaces__action__DimLights_Goal__get_type_description(NULL)->type_description.fields;
    description.referenced_type_descriptions.data[8].fields = custom_action_interfaces__action__DimLights_Result__get_type_description(NULL)->type_description.fields;
    description.referenced_type_descriptions.data[9].fields = custom_action_interfaces__action__DimLights_SendGoal__get_type_description(NULL)->type_description.fields;
    description.referenced_type_descriptions.data[10].fields = custom_action_interfaces__action__DimLights_SendGoal_Event__get_type_description(NULL)->type_description.fields;
    description.referenced_type_descriptions.data[11].fields = custom_action_interfaces__action__DimLights_SendGoal_Request__get_type_description(NULL)->type_description.fields;
    description.referenced_type_descriptions.data[12].fields = custom_action_interfaces__action__DimLights_SendGoal_Response__get_type_description(NULL)->type_description.fields;
    assert(0 == memcmp(&service_msgs__msg__ServiceEventInfo__EXPECTED_HASH, service_msgs__msg__ServiceEventInfo__get_type_hash(NULL), sizeof(rosidl_type_hash_t)));
    description.referenced_type_descriptions.data[13].fields = service_msgs__msg__ServiceEventInfo__get_type_description(NULL)->type_description.fields;
    assert(0 == memcmp(&unique_identifier_msgs__msg__UUID__EXPECTED_HASH, unique_identifier_msgs__msg__UUID__get_type_hash(NULL), sizeof(rosidl_type_hash_t)));
    description.referenced_type_descriptions.data[14].fields = unique_identifier_msgs__msg__UUID__get_type_description(NULL)->type_description.fields;
    constructed = true;
  }
  return &description;
}
// Define type names, field names, and default values
static char custom_action_interfaces__action__DimLights_Goal__FIELD_NAME__target_brightness[] = "target_brightness";

static rosidl_runtime_c__type_description__Field custom_action_interfaces__action__DimLights_Goal__FIELDS[] = {
  {
    {custom_action_interfaces__action__DimLights_Goal__FIELD_NAME__target_brightness, 17, 17},
    {
      rosidl_runtime_c__type_description__FieldType__FIELD_TYPE_FLOAT,
      0,
      0,
      {NULL, 0, 0},
    },
    {NULL, 0, 0},
  },
};

const rosidl_runtime_c__type_description__TypeDescription *
custom_action_interfaces__action__DimLights_Goal__get_type_description(
  const rosidl_message_type_support_t * type_support)
{
  (void)type_support;
  static bool constructed = false;
  static const rosidl_runtime_c__type_description__TypeDescription description = {
    {
      {custom_action_interfaces__action__DimLights_Goal__TYPE_NAME, 46, 46},
      {custom_action_interfaces__action__DimLights_Goal__FIELDS, 1, 1},
    },
    {NULL, 0, 0},
  };
  if (!constructed) {
    constructed = true;
  }
  return &description;
}
// Define type names, field names, and default values
static char custom_action_interfaces__action__DimLights_Result__FIELD_NAME__current_brightness[] = "current_brightness";

static rosidl_runtime_c__type_description__Field custom_action_interfaces__action__DimLights_Result__FIELDS[] = {
  {
    {custom_action_interfaces__action__DimLights_Result__FIELD_NAME__current_brightness, 18, 18},
    {
      rosidl_runtime_c__type_description__FieldType__FIELD_TYPE_FLOAT,
      0,
      0,
      {NULL, 0, 0},
    },
    {NULL, 0, 0},
  },
};

const rosidl_runtime_c__type_description__TypeDescription *
custom_action_interfaces__action__DimLights_Result__get_type_description(
  const rosidl_message_type_support_t * type_support)
{
  (void)type_support;
  static bool constructed = false;
  static const rosidl_runtime_c__type_description__TypeDescription description = {
    {
      {custom_action_interfaces__action__DimLights_Result__TYPE_NAME, 48, 48},
      {custom_action_interfaces__action__DimLights_Result__FIELDS, 1, 1},
    },
    {NULL, 0, 0},
  };
  if (!constructed) {
    constructed = true;
  }
  return &description;
}
// Define type names, field names, and default values
static char custom_action_interfaces__action__DimLights_Feedback__FIELD_NAME__success[] = "success";

static rosidl_runtime_c__type_description__Field custom_action_interfaces__action__DimLights_Feedback__FIELDS[] = {
  {
    {custom_action_interfaces__action__DimLights_Feedback__FIELD_NAME__success, 7, 7},
    {
      rosidl_runtime_c__type_description__FieldType__FIELD_TYPE_BOOLEAN,
      0,
      0,
      {NULL, 0, 0},
    },
    {NULL, 0, 0},
  },
};

const rosidl_runtime_c__type_description__TypeDescription *
custom_action_interfaces__action__DimLights_Feedback__get_type_description(
  const rosidl_message_type_support_t * type_support)
{
  (void)type_support;
  static bool constructed = false;
  static const rosidl_runtime_c__type_description__TypeDescription description = {
    {
      {custom_action_interfaces__action__DimLights_Feedback__TYPE_NAME, 50, 50},
      {custom_action_interfaces__action__DimLights_Feedback__FIELDS, 1, 1},
    },
    {NULL, 0, 0},
  };
  if (!constructed) {
    constructed = true;
  }
  return &description;
}
// Define type names, field names, and default values
static char custom_action_interfaces__action__DimLights_SendGoal__FIELD_NAME__request_message[] = "request_message";
static char custom_action_interfaces__action__DimLights_SendGoal__FIELD_NAME__response_message[] = "response_message";
static char custom_action_interfaces__action__DimLights_SendGoal__FIELD_NAME__event_message[] = "event_message";

static rosidl_runtime_c__type_description__Field custom_action_interfaces__action__DimLights_SendGoal__FIELDS[] = {
  {
    {custom_action_interfaces__action__DimLights_SendGoal__FIELD_NAME__request_message, 15, 15},
    {
      rosidl_runtime_c__type_description__FieldType__FIELD_TYPE_NESTED_TYPE,
      0,
      0,
      {custom_action_interfaces__action__DimLights_SendGoal_Request__TYPE_NAME, 58, 58},
    },
    {NULL, 0, 0},
  },
  {
    {custom_action_interfaces__action__DimLights_SendGoal__FIELD_NAME__response_message, 16, 16},
    {
      rosidl_runtime_c__type_description__FieldType__FIELD_TYPE_NESTED_TYPE,
      0,
      0,
      {custom_action_interfaces__action__DimLights_SendGoal_Response__TYPE_NAME, 59, 59},
    },
    {NULL, 0, 0},
  },
  {
    {custom_action_interfaces__action__DimLights_SendGoal__FIELD_NAME__event_message, 13, 13},
    {
      rosidl_runtime_c__type_description__FieldType__FIELD_TYPE_NESTED_TYPE,
      0,
      0,
      {custom_action_interfaces__action__DimLights_SendGoal_Event__TYPE_NAME, 56, 56},
    },
    {NULL, 0, 0},
  },
};

static rosidl_runtime_c__type_description__IndividualTypeDescription custom_action_interfaces__action__DimLights_SendGoal__REFERENCED_TYPE_DESCRIPTIONS[] = {
  {
    {builtin_interfaces__msg__Time__TYPE_NAME, 27, 27},
    {NULL, 0, 0},
  },
  {
    {custom_action_interfaces__action__DimLights_Goal__TYPE_NAME, 46, 46},
    {NULL, 0, 0},
  },
  {
    {custom_action_interfaces__action__DimLights_SendGoal_Event__TYPE_NAME, 56, 56},
    {NULL, 0, 0},
  },
  {
    {custom_action_interfaces__action__DimLights_SendGoal_Request__TYPE_NAME, 58, 58},
    {NULL, 0, 0},
  },
  {
    {custom_action_interfaces__action__DimLights_SendGoal_Response__TYPE_NAME, 59, 59},
    {NULL, 0, 0},
  },
  {
    {service_msgs__msg__ServiceEventInfo__TYPE_NAME, 33, 33},
    {NULL, 0, 0},
  },
  {
    {unique_identifier_msgs__msg__UUID__TYPE_NAME, 31, 31},
    {NULL, 0, 0},
  },
};

const rosidl_runtime_c__type_description__TypeDescription *
custom_action_interfaces__action__DimLights_SendGoal__get_type_description(
  const rosidl_service_type_support_t * type_support)
{
  (void)type_support;
  static bool constructed = false;
  static const rosidl_runtime_c__type_description__TypeDescription description = {
    {
      {custom_action_interfaces__action__DimLights_SendGoal__TYPE_NAME, 50, 50},
      {custom_action_interfaces__action__DimLights_SendGoal__FIELDS, 3, 3},
    },
    {custom_action_interfaces__action__DimLights_SendGoal__REFERENCED_TYPE_DESCRIPTIONS, 7, 7},
  };
  if (!constructed) {
    assert(0 == memcmp(&builtin_interfaces__msg__Time__EXPECTED_HASH, builtin_interfaces__msg__Time__get_type_hash(NULL), sizeof(rosidl_type_hash_t)));
    description.referenced_type_descriptions.data[0].fields = builtin_interfaces__msg__Time__get_type_description(NULL)->type_description.fields;
    description.referenced_type_descriptions.data[1].fields = custom_action_interfaces__action__DimLights_Goal__get_type_description(NULL)->type_description.fields;
    description.referenced_type_descriptions.data[2].fields = custom_action_interfaces__action__DimLights_SendGoal_Event__get_type_description(NULL)->type_description.fields;
    description.referenced_type_descriptions.data[3].fields = custom_action_interfaces__action__DimLights_SendGoal_Request__get_type_description(NULL)->type_description.fields;
    description.referenced_type_descriptions.data[4].fields = custom_action_interfaces__action__DimLights_SendGoal_Response__get_type_description(NULL)->type_description.fields;
    assert(0 == memcmp(&service_msgs__msg__ServiceEventInfo__EXPECTED_HASH, service_msgs__msg__ServiceEventInfo__get_type_hash(NULL), sizeof(rosidl_type_hash_t)));
    description.referenced_type_descriptions.data[5].fields = service_msgs__msg__ServiceEventInfo__get_type_description(NULL)->type_description.fields;
    assert(0 == memcmp(&unique_identifier_msgs__msg__UUID__EXPECTED_HASH, unique_identifier_msgs__msg__UUID__get_type_hash(NULL), sizeof(rosidl_type_hash_t)));
    description.referenced_type_descriptions.data[6].fields = unique_identifier_msgs__msg__UUID__get_type_description(NULL)->type_description.fields;
    constructed = true;
  }
  return &description;
}
// Define type names, field names, and default values
static char custom_action_interfaces__action__DimLights_SendGoal_Request__FIELD_NAME__goal_id[] = "goal_id";
static char custom_action_interfaces__action__DimLights_SendGoal_Request__FIELD_NAME__goal[] = "goal";

static rosidl_runtime_c__type_description__Field custom_action_interfaces__action__DimLights_SendGoal_Request__FIELDS[] = {
  {
    {custom_action_interfaces__action__DimLights_SendGoal_Request__FIELD_NAME__goal_id, 7, 7},
    {
      rosidl_runtime_c__type_description__FieldType__FIELD_TYPE_NESTED_TYPE,
      0,
      0,
      {unique_identifier_msgs__msg__UUID__TYPE_NAME, 31, 31},
    },
    {NULL, 0, 0},
  },
  {
    {custom_action_interfaces__action__DimLights_SendGoal_Request__FIELD_NAME__goal, 4, 4},
    {
      rosidl_runtime_c__type_description__FieldType__FIELD_TYPE_NESTED_TYPE,
      0,
      0,
      {custom_action_interfaces__action__DimLights_Goal__TYPE_NAME, 46, 46},
    },
    {NULL, 0, 0},
  },
};

static rosidl_runtime_c__type_description__IndividualTypeDescription custom_action_interfaces__action__DimLights_SendGoal_Request__REFERENCED_TYPE_DESCRIPTIONS[] = {
  {
    {custom_action_interfaces__action__DimLights_Goal__TYPE_NAME, 46, 46},
    {NULL, 0, 0},
  },
  {
    {unique_identifier_msgs__msg__UUID__TYPE_NAME, 31, 31},
    {NULL, 0, 0},
  },
};

const rosidl_runtime_c__type_description__TypeDescription *
custom_action_interfaces__action__DimLights_SendGoal_Request__get_type_description(
  const rosidl_message_type_support_t * type_support)
{
  (void)type_support;
  static bool constructed = false;
  static const rosidl_runtime_c__type_description__TypeDescription description = {
    {
      {custom_action_interfaces__action__DimLights_SendGoal_Request__TYPE_NAME, 58, 58},
      {custom_action_interfaces__action__DimLights_SendGoal_Request__FIELDS, 2, 2},
    },
    {custom_action_interfaces__action__DimLights_SendGoal_Request__REFERENCED_TYPE_DESCRIPTIONS, 2, 2},
  };
  if (!constructed) {
    description.referenced_type_descriptions.data[0].fields = custom_action_interfaces__action__DimLights_Goal__get_type_description(NULL)->type_description.fields;
    assert(0 == memcmp(&unique_identifier_msgs__msg__UUID__EXPECTED_HASH, unique_identifier_msgs__msg__UUID__get_type_hash(NULL), sizeof(rosidl_type_hash_t)));
    description.referenced_type_descriptions.data[1].fields = unique_identifier_msgs__msg__UUID__get_type_description(NULL)->type_description.fields;
    constructed = true;
  }
  return &description;
}
// Define type names, field names, and default values
static char custom_action_interfaces__action__DimLights_SendGoal_Response__FIELD_NAME__accepted[] = "accepted";
static char custom_action_interfaces__action__DimLights_SendGoal_Response__FIELD_NAME__stamp[] = "stamp";

static rosidl_runtime_c__type_description__Field custom_action_interfaces__action__DimLights_SendGoal_Response__FIELDS[] = {
  {
    {custom_action_interfaces__action__DimLights_SendGoal_Response__FIELD_NAME__accepted, 8, 8},
    {
      rosidl_runtime_c__type_description__FieldType__FIELD_TYPE_BOOLEAN,
      0,
      0,
      {NULL, 0, 0},
    },
    {NULL, 0, 0},
  },
  {
    {custom_action_interfaces__action__DimLights_SendGoal_Response__FIELD_NAME__stamp, 5, 5},
    {
      rosidl_runtime_c__type_description__FieldType__FIELD_TYPE_NESTED_TYPE,
      0,
      0,
      {builtin_interfaces__msg__Time__TYPE_NAME, 27, 27},
    },
    {NULL, 0, 0},
  },
};

static rosidl_runtime_c__type_description__IndividualTypeDescription custom_action_interfaces__action__DimLights_SendGoal_Response__REFERENCED_TYPE_DESCRIPTIONS[] = {
  {
    {builtin_interfaces__msg__Time__TYPE_NAME, 27, 27},
    {NULL, 0, 0},
  },
};

const rosidl_runtime_c__type_description__TypeDescription *
custom_action_interfaces__action__DimLights_SendGoal_Response__get_type_description(
  const rosidl_message_type_support_t * type_support)
{
  (void)type_support;
  static bool constructed = false;
  static const rosidl_runtime_c__type_description__TypeDescription description = {
    {
      {custom_action_interfaces__action__DimLights_SendGoal_Response__TYPE_NAME, 59, 59},
      {custom_action_interfaces__action__DimLights_SendGoal_Response__FIELDS, 2, 2},
    },
    {custom_action_interfaces__action__DimLights_SendGoal_Response__REFERENCED_TYPE_DESCRIPTIONS, 1, 1},
  };
  if (!constructed) {
    assert(0 == memcmp(&builtin_interfaces__msg__Time__EXPECTED_HASH, builtin_interfaces__msg__Time__get_type_hash(NULL), sizeof(rosidl_type_hash_t)));
    description.referenced_type_descriptions.data[0].fields = builtin_interfaces__msg__Time__get_type_description(NULL)->type_description.fields;
    constructed = true;
  }
  return &description;
}
// Define type names, field names, and default values
static char custom_action_interfaces__action__DimLights_SendGoal_Event__FIELD_NAME__info[] = "info";
static char custom_action_interfaces__action__DimLights_SendGoal_Event__FIELD_NAME__request[] = "request";
static char custom_action_interfaces__action__DimLights_SendGoal_Event__FIELD_NAME__response[] = "response";

static rosidl_runtime_c__type_description__Field custom_action_interfaces__action__DimLights_SendGoal_Event__FIELDS[] = {
  {
    {custom_action_interfaces__action__DimLights_SendGoal_Event__FIELD_NAME__info, 4, 4},
    {
      rosidl_runtime_c__type_description__FieldType__FIELD_TYPE_NESTED_TYPE,
      0,
      0,
      {service_msgs__msg__ServiceEventInfo__TYPE_NAME, 33, 33},
    },
    {NULL, 0, 0},
  },
  {
    {custom_action_interfaces__action__DimLights_SendGoal_Event__FIELD_NAME__request, 7, 7},
    {
      rosidl_runtime_c__type_description__FieldType__FIELD_TYPE_NESTED_TYPE_BOUNDED_SEQUENCE,
      1,
      0,
      {custom_action_interfaces__action__DimLights_SendGoal_Request__TYPE_NAME, 58, 58},
    },
    {NULL, 0, 0},
  },
  {
    {custom_action_interfaces__action__DimLights_SendGoal_Event__FIELD_NAME__response, 8, 8},
    {
      rosidl_runtime_c__type_description__FieldType__FIELD_TYPE_NESTED_TYPE_BOUNDED_SEQUENCE,
      1,
      0,
      {custom_action_interfaces__action__DimLights_SendGoal_Response__TYPE_NAME, 59, 59},
    },
    {NULL, 0, 0},
  },
};

static rosidl_runtime_c__type_description__IndividualTypeDescription custom_action_interfaces__action__DimLights_SendGoal_Event__REFERENCED_TYPE_DESCRIPTIONS[] = {
  {
    {builtin_interfaces__msg__Time__TYPE_NAME, 27, 27},
    {NULL, 0, 0},
  },
  {
    {custom_action_interfaces__action__DimLights_Goal__TYPE_NAME, 46, 46},
    {NULL, 0, 0},
  },
  {
    {custom_action_interfaces__action__DimLights_SendGoal_Request__TYPE_NAME, 58, 58},
    {NULL, 0, 0},
  },
  {
    {custom_action_interfaces__action__DimLights_SendGoal_Response__TYPE_NAME, 59, 59},
    {NULL, 0, 0},
  },
  {
    {service_msgs__msg__ServiceEventInfo__TYPE_NAME, 33, 33},
    {NULL, 0, 0},
  },
  {
    {unique_identifier_msgs__msg__UUID__TYPE_NAME, 31, 31},
    {NULL, 0, 0},
  },
};

const rosidl_runtime_c__type_description__TypeDescription *
custom_action_interfaces__action__DimLights_SendGoal_Event__get_type_description(
  const rosidl_message_type_support_t * type_support)
{
  (void)type_support;
  static bool constructed = false;
  static const rosidl_runtime_c__type_description__TypeDescription description = {
    {
      {custom_action_interfaces__action__DimLights_SendGoal_Event__TYPE_NAME, 56, 56},
      {custom_action_interfaces__action__DimLights_SendGoal_Event__FIELDS, 3, 3},
    },
    {custom_action_interfaces__action__DimLights_SendGoal_Event__REFERENCED_TYPE_DESCRIPTIONS, 6, 6},
  };
  if (!constructed) {
    assert(0 == memcmp(&builtin_interfaces__msg__Time__EXPECTED_HASH, builtin_interfaces__msg__Time__get_type_hash(NULL), sizeof(rosidl_type_hash_t)));
    description.referenced_type_descriptions.data[0].fields = builtin_interfaces__msg__Time__get_type_description(NULL)->type_description.fields;
    description.referenced_type_descriptions.data[1].fields = custom_action_interfaces__action__DimLights_Goal__get_type_description(NULL)->type_description.fields;
    description.referenced_type_descriptions.data[2].fields = custom_action_interfaces__action__DimLights_SendGoal_Request__get_type_description(NULL)->type_description.fields;
    description.referenced_type_descriptions.data[3].fields = custom_action_interfaces__action__DimLights_SendGoal_Response__get_type_description(NULL)->type_description.fields;
    assert(0 == memcmp(&service_msgs__msg__ServiceEventInfo__EXPECTED_HASH, service_msgs__msg__ServiceEventInfo__get_type_hash(NULL), sizeof(rosidl_type_hash_t)));
    description.referenced_type_descriptions.data[4].fields = service_msgs__msg__ServiceEventInfo__get_type_description(NULL)->type_description.fields;
    assert(0 == memcmp(&unique_identifier_msgs__msg__UUID__EXPECTED_HASH, unique_identifier_msgs__msg__UUID__get_type_hash(NULL), sizeof(rosidl_type_hash_t)));
    description.referenced_type_descriptions.data[5].fields = unique_identifier_msgs__msg__UUID__get_type_description(NULL)->type_description.fields;
    constructed = true;
  }
  return &description;
}
// Define type names, field names, and default values
static char custom_action_interfaces__action__DimLights_GetResult__FIELD_NAME__request_message[] = "request_message";
static char custom_action_interfaces__action__DimLights_GetResult__FIELD_NAME__response_message[] = "response_message";
static char custom_action_interfaces__action__DimLights_GetResult__FIELD_NAME__event_message[] = "event_message";

static rosidl_runtime_c__type_description__Field custom_action_interfaces__action__DimLights_GetResult__FIELDS[] = {
  {
    {custom_action_interfaces__action__DimLights_GetResult__FIELD_NAME__request_message, 15, 15},
    {
      rosidl_runtime_c__type_description__FieldType__FIELD_TYPE_NESTED_TYPE,
      0,
      0,
      {custom_action_interfaces__action__DimLights_GetResult_Request__TYPE_NAME, 59, 59},
    },
    {NULL, 0, 0},
  },
  {
    {custom_action_interfaces__action__DimLights_GetResult__FIELD_NAME__response_message, 16, 16},
    {
      rosidl_runtime_c__type_description__FieldType__FIELD_TYPE_NESTED_TYPE,
      0,
      0,
      {custom_action_interfaces__action__DimLights_GetResult_Response__TYPE_NAME, 60, 60},
    },
    {NULL, 0, 0},
  },
  {
    {custom_action_interfaces__action__DimLights_GetResult__FIELD_NAME__event_message, 13, 13},
    {
      rosidl_runtime_c__type_description__FieldType__FIELD_TYPE_NESTED_TYPE,
      0,
      0,
      {custom_action_interfaces__action__DimLights_GetResult_Event__TYPE_NAME, 57, 57},
    },
    {NULL, 0, 0},
  },
};

static rosidl_runtime_c__type_description__IndividualTypeDescription custom_action_interfaces__action__DimLights_GetResult__REFERENCED_TYPE_DESCRIPTIONS[] = {
  {
    {builtin_interfaces__msg__Time__TYPE_NAME, 27, 27},
    {NULL, 0, 0},
  },
  {
    {custom_action_interfaces__action__DimLights_GetResult_Event__TYPE_NAME, 57, 57},
    {NULL, 0, 0},
  },
  {
    {custom_action_interfaces__action__DimLights_GetResult_Request__TYPE_NAME, 59, 59},
    {NULL, 0, 0},
  },
  {
    {custom_action_interfaces__action__DimLights_GetResult_Response__TYPE_NAME, 60, 60},
    {NULL, 0, 0},
  },
  {
    {custom_action_interfaces__action__DimLights_Result__TYPE_NAME, 48, 48},
    {NULL, 0, 0},
  },
  {
    {service_msgs__msg__ServiceEventInfo__TYPE_NAME, 33, 33},
    {NULL, 0, 0},
  },
  {
    {unique_identifier_msgs__msg__UUID__TYPE_NAME, 31, 31},
    {NULL, 0, 0},
  },
};

const rosidl_runtime_c__type_description__TypeDescription *
custom_action_interfaces__action__DimLights_GetResult__get_type_description(
  const rosidl_service_type_support_t * type_support)
{
  (void)type_support;
  static bool constructed = false;
  static const rosidl_runtime_c__type_description__TypeDescription description = {
    {
      {custom_action_interfaces__action__DimLights_GetResult__TYPE_NAME, 51, 51},
      {custom_action_interfaces__action__DimLights_GetResult__FIELDS, 3, 3},
    },
    {custom_action_interfaces__action__DimLights_GetResult__REFERENCED_TYPE_DESCRIPTIONS, 7, 7},
  };
  if (!constructed) {
    assert(0 == memcmp(&builtin_interfaces__msg__Time__EXPECTED_HASH, builtin_interfaces__msg__Time__get_type_hash(NULL), sizeof(rosidl_type_hash_t)));
    description.referenced_type_descriptions.data[0].fields = builtin_interfaces__msg__Time__get_type_description(NULL)->type_description.fields;
    description.referenced_type_descriptions.data[1].fields = custom_action_interfaces__action__DimLights_GetResult_Event__get_type_description(NULL)->type_description.fields;
    description.referenced_type_descriptions.data[2].fields = custom_action_interfaces__action__DimLights_GetResult_Request__get_type_description(NULL)->type_description.fields;
    description.referenced_type_descriptions.data[3].fields = custom_action_interfaces__action__DimLights_GetResult_Response__get_type_description(NULL)->type_description.fields;
    description.referenced_type_descriptions.data[4].fields = custom_action_interfaces__action__DimLights_Result__get_type_description(NULL)->type_description.fields;
    assert(0 == memcmp(&service_msgs__msg__ServiceEventInfo__EXPECTED_HASH, service_msgs__msg__ServiceEventInfo__get_type_hash(NULL), sizeof(rosidl_type_hash_t)));
    description.referenced_type_descriptions.data[5].fields = service_msgs__msg__ServiceEventInfo__get_type_description(NULL)->type_description.fields;
    assert(0 == memcmp(&unique_identifier_msgs__msg__UUID__EXPECTED_HASH, unique_identifier_msgs__msg__UUID__get_type_hash(NULL), sizeof(rosidl_type_hash_t)));
    description.referenced_type_descriptions.data[6].fields = unique_identifier_msgs__msg__UUID__get_type_description(NULL)->type_description.fields;
    constructed = true;
  }
  return &description;
}
// Define type names, field names, and default values
static char custom_action_interfaces__action__DimLights_GetResult_Request__FIELD_NAME__goal_id[] = "goal_id";

static rosidl_runtime_c__type_description__Field custom_action_interfaces__action__DimLights_GetResult_Request__FIELDS[] = {
  {
    {custom_action_interfaces__action__DimLights_GetResult_Request__FIELD_NAME__goal_id, 7, 7},
    {
      rosidl_runtime_c__type_description__FieldType__FIELD_TYPE_NESTED_TYPE,
      0,
      0,
      {unique_identifier_msgs__msg__UUID__TYPE_NAME, 31, 31},
    },
    {NULL, 0, 0},
  },
};

static rosidl_runtime_c__type_description__IndividualTypeDescription custom_action_interfaces__action__DimLights_GetResult_Request__REFERENCED_TYPE_DESCRIPTIONS[] = {
  {
    {unique_identifier_msgs__msg__UUID__TYPE_NAME, 31, 31},
    {NULL, 0, 0},
  },
};

const rosidl_runtime_c__type_description__TypeDescription *
custom_action_interfaces__action__DimLights_GetResult_Request__get_type_description(
  const rosidl_message_type_support_t * type_support)
{
  (void)type_support;
  static bool constructed = false;
  static const rosidl_runtime_c__type_description__TypeDescription description = {
    {
      {custom_action_interfaces__action__DimLights_GetResult_Request__TYPE_NAME, 59, 59},
      {custom_action_interfaces__action__DimLights_GetResult_Request__FIELDS, 1, 1},
    },
    {custom_action_interfaces__action__DimLights_GetResult_Request__REFERENCED_TYPE_DESCRIPTIONS, 1, 1},
  };
  if (!constructed) {
    assert(0 == memcmp(&unique_identifier_msgs__msg__UUID__EXPECTED_HASH, unique_identifier_msgs__msg__UUID__get_type_hash(NULL), sizeof(rosidl_type_hash_t)));
    description.referenced_type_descriptions.data[0].fields = unique_identifier_msgs__msg__UUID__get_type_description(NULL)->type_description.fields;
    constructed = true;
  }
  return &description;
}
// Define type names, field names, and default values
static char custom_action_interfaces__action__DimLights_GetResult_Response__FIELD_NAME__status[] = "status";
static char custom_action_interfaces__action__DimLights_GetResult_Response__FIELD_NAME__result[] = "result";

static rosidl_runtime_c__type_description__Field custom_action_interfaces__action__DimLights_GetResult_Response__FIELDS[] = {
  {
    {custom_action_interfaces__action__DimLights_GetResult_Response__FIELD_NAME__status, 6, 6},
    {
      rosidl_runtime_c__type_description__FieldType__FIELD_TYPE_INT8,
      0,
      0,
      {NULL, 0, 0},
    },
    {NULL, 0, 0},
  },
  {
    {custom_action_interfaces__action__DimLights_GetResult_Response__FIELD_NAME__result, 6, 6},
    {
      rosidl_runtime_c__type_description__FieldType__FIELD_TYPE_NESTED_TYPE,
      0,
      0,
      {custom_action_interfaces__action__DimLights_Result__TYPE_NAME, 48, 48},
    },
    {NULL, 0, 0},
  },
};

static rosidl_runtime_c__type_description__IndividualTypeDescription custom_action_interfaces__action__DimLights_GetResult_Response__REFERENCED_TYPE_DESCRIPTIONS[] = {
  {
    {custom_action_interfaces__action__DimLights_Result__TYPE_NAME, 48, 48},
    {NULL, 0, 0},
  },
};

const rosidl_runtime_c__type_description__TypeDescription *
custom_action_interfaces__action__DimLights_GetResult_Response__get_type_description(
  const rosidl_message_type_support_t * type_support)
{
  (void)type_support;
  static bool constructed = false;
  static const rosidl_runtime_c__type_description__TypeDescription description = {
    {
      {custom_action_interfaces__action__DimLights_GetResult_Response__TYPE_NAME, 60, 60},
      {custom_action_interfaces__action__DimLights_GetResult_Response__FIELDS, 2, 2},
    },
    {custom_action_interfaces__action__DimLights_GetResult_Response__REFERENCED_TYPE_DESCRIPTIONS, 1, 1},
  };
  if (!constructed) {
    description.referenced_type_descriptions.data[0].fields = custom_action_interfaces__action__DimLights_Result__get_type_description(NULL)->type_description.fields;
    constructed = true;
  }
  return &description;
}
// Define type names, field names, and default values
static char custom_action_interfaces__action__DimLights_GetResult_Event__FIELD_NAME__info[] = "info";
static char custom_action_interfaces__action__DimLights_GetResult_Event__FIELD_NAME__request[] = "request";
static char custom_action_interfaces__action__DimLights_GetResult_Event__FIELD_NAME__response[] = "response";

static rosidl_runtime_c__type_description__Field custom_action_interfaces__action__DimLights_GetResult_Event__FIELDS[] = {
  {
    {custom_action_interfaces__action__DimLights_GetResult_Event__FIELD_NAME__info, 4, 4},
    {
      rosidl_runtime_c__type_description__FieldType__FIELD_TYPE_NESTED_TYPE,
      0,
      0,
      {service_msgs__msg__ServiceEventInfo__TYPE_NAME, 33, 33},
    },
    {NULL, 0, 0},
  },
  {
    {custom_action_interfaces__action__DimLights_GetResult_Event__FIELD_NAME__request, 7, 7},
    {
      rosidl_runtime_c__type_description__FieldType__FIELD_TYPE_NESTED_TYPE_BOUNDED_SEQUENCE,
      1,
      0,
      {custom_action_interfaces__action__DimLights_GetResult_Request__TYPE_NAME, 59, 59},
    },
    {NULL, 0, 0},
  },
  {
    {custom_action_interfaces__action__DimLights_GetResult_Event__FIELD_NAME__response, 8, 8},
    {
      rosidl_runtime_c__type_description__FieldType__FIELD_TYPE_NESTED_TYPE_BOUNDED_SEQUENCE,
      1,
      0,
      {custom_action_interfaces__action__DimLights_GetResult_Response__TYPE_NAME, 60, 60},
    },
    {NULL, 0, 0},
  },
};

static rosidl_runtime_c__type_description__IndividualTypeDescription custom_action_interfaces__action__DimLights_GetResult_Event__REFERENCED_TYPE_DESCRIPTIONS[] = {
  {
    {builtin_interfaces__msg__Time__TYPE_NAME, 27, 27},
    {NULL, 0, 0},
  },
  {
    {custom_action_interfaces__action__DimLights_GetResult_Request__TYPE_NAME, 59, 59},
    {NULL, 0, 0},
  },
  {
    {custom_action_interfaces__action__DimLights_GetResult_Response__TYPE_NAME, 60, 60},
    {NULL, 0, 0},
  },
  {
    {custom_action_interfaces__action__DimLights_Result__TYPE_NAME, 48, 48},
    {NULL, 0, 0},
  },
  {
    {service_msgs__msg__ServiceEventInfo__TYPE_NAME, 33, 33},
    {NULL, 0, 0},
  },
  {
    {unique_identifier_msgs__msg__UUID__TYPE_NAME, 31, 31},
    {NULL, 0, 0},
  },
};

const rosidl_runtime_c__type_description__TypeDescription *
custom_action_interfaces__action__DimLights_GetResult_Event__get_type_description(
  const rosidl_message_type_support_t * type_support)
{
  (void)type_support;
  static bool constructed = false;
  static const rosidl_runtime_c__type_description__TypeDescription description = {
    {
      {custom_action_interfaces__action__DimLights_GetResult_Event__TYPE_NAME, 57, 57},
      {custom_action_interfaces__action__DimLights_GetResult_Event__FIELDS, 3, 3},
    },
    {custom_action_interfaces__action__DimLights_GetResult_Event__REFERENCED_TYPE_DESCRIPTIONS, 6, 6},
  };
  if (!constructed) {
    assert(0 == memcmp(&builtin_interfaces__msg__Time__EXPECTED_HASH, builtin_interfaces__msg__Time__get_type_hash(NULL), sizeof(rosidl_type_hash_t)));
    description.referenced_type_descriptions.data[0].fields = builtin_interfaces__msg__Time__get_type_description(NULL)->type_description.fields;
    description.referenced_type_descriptions.data[1].fields = custom_action_interfaces__action__DimLights_GetResult_Request__get_type_description(NULL)->type_description.fields;
    description.referenced_type_descriptions.data[2].fields = custom_action_interfaces__action__DimLights_GetResult_Response__get_type_description(NULL)->type_description.fields;
    description.referenced_type_descriptions.data[3].fields = custom_action_interfaces__action__DimLights_Result__get_type_description(NULL)->type_description.fields;
    assert(0 == memcmp(&service_msgs__msg__ServiceEventInfo__EXPECTED_HASH, service_msgs__msg__ServiceEventInfo__get_type_hash(NULL), sizeof(rosidl_type_hash_t)));
    description.referenced_type_descriptions.data[4].fields = service_msgs__msg__ServiceEventInfo__get_type_description(NULL)->type_description.fields;
    assert(0 == memcmp(&unique_identifier_msgs__msg__UUID__EXPECTED_HASH, unique_identifier_msgs__msg__UUID__get_type_hash(NULL), sizeof(rosidl_type_hash_t)));
    description.referenced_type_descriptions.data[5].fields = unique_identifier_msgs__msg__UUID__get_type_description(NULL)->type_description.fields;
    constructed = true;
  }
  return &description;
}
// Define type names, field names, and default values
static char custom_action_interfaces__action__DimLights_FeedbackMessage__FIELD_NAME__goal_id[] = "goal_id";
static char custom_action_interfaces__action__DimLights_FeedbackMessage__FIELD_NAME__feedback[] = "feedback";

static rosidl_runtime_c__type_description__Field custom_action_interfaces__action__DimLights_FeedbackMessage__FIELDS[] = {
  {
    {custom_action_interfaces__action__DimLights_FeedbackMessage__FIELD_NAME__goal_id, 7, 7},
    {
      rosidl_runtime_c__type_description__FieldType__FIELD_TYPE_NESTED_TYPE,
      0,
      0,
      {unique_identifier_msgs__msg__UUID__TYPE_NAME, 31, 31},
    },
    {NULL, 0, 0},
  },
  {
    {custom_action_interfaces__action__DimLights_FeedbackMessage__FIELD_NAME__feedback, 8, 8},
    {
      rosidl_runtime_c__type_description__FieldType__FIELD_TYPE_NESTED_TYPE,
      0,
      0,
      {custom_action_interfaces__action__DimLights_Feedback__TYPE_NAME, 50, 50},
    },
    {NULL, 0, 0},
  },
};

static rosidl_runtime_c__type_description__IndividualTypeDescription custom_action_interfaces__action__DimLights_FeedbackMessage__REFERENCED_TYPE_DESCRIPTIONS[] = {
  {
    {custom_action_interfaces__action__DimLights_Feedback__TYPE_NAME, 50, 50},
    {NULL, 0, 0},
  },
  {
    {unique_identifier_msgs__msg__UUID__TYPE_NAME, 31, 31},
    {NULL, 0, 0},
  },
};

const rosidl_runtime_c__type_description__TypeDescription *
custom_action_interfaces__action__DimLights_FeedbackMessage__get_type_description(
  const rosidl_message_type_support_t * type_support)
{
  (void)type_support;
  static bool constructed = false;
  static const rosidl_runtime_c__type_description__TypeDescription description = {
    {
      {custom_action_interfaces__action__DimLights_FeedbackMessage__TYPE_NAME, 57, 57},
      {custom_action_interfaces__action__DimLights_FeedbackMessage__FIELDS, 2, 2},
    },
    {custom_action_interfaces__action__DimLights_FeedbackMessage__REFERENCED_TYPE_DESCRIPTIONS, 2, 2},
  };
  if (!constructed) {
    description.referenced_type_descriptions.data[0].fields = custom_action_interfaces__action__DimLights_Feedback__get_type_description(NULL)->type_description.fields;
    assert(0 == memcmp(&unique_identifier_msgs__msg__UUID__EXPECTED_HASH, unique_identifier_msgs__msg__UUID__get_type_hash(NULL), sizeof(rosidl_type_hash_t)));
    description.referenced_type_descriptions.data[1].fields = unique_identifier_msgs__msg__UUID__get_type_description(NULL)->type_description.fields;
    constructed = true;
  }
  return &description;
}

static char toplevel_type_raw_source[] =
  "# Goal\n"
  "float32 target_brightness\n"
  "\n"
  "---\n"
  "# Feedback\n"
  "float32 current_brightness\n"
  "\n"
  "---\n"
  "# Result\n"
  "bool success\n"
  "";

static char action_encoding[] = "action";
static char implicit_encoding[] = "implicit";

// Define all individual source functions

const rosidl_runtime_c__type_description__TypeSource *
custom_action_interfaces__action__DimLights__get_individual_type_description_source(
  const rosidl_action_type_support_t * type_support)
{
  (void)type_support;
  static const rosidl_runtime_c__type_description__TypeSource source = {
    {custom_action_interfaces__action__DimLights__TYPE_NAME, 41, 41},
    {action_encoding, 6, 6},
    {toplevel_type_raw_source, 104, 104},
  };
  return &source;
}

const rosidl_runtime_c__type_description__TypeSource *
custom_action_interfaces__action__DimLights_Goal__get_individual_type_description_source(
  const rosidl_message_type_support_t * type_support)
{
  (void)type_support;
  static const rosidl_runtime_c__type_description__TypeSource source = {
    {custom_action_interfaces__action__DimLights_Goal__TYPE_NAME, 46, 46},
    {implicit_encoding, 8, 8},
    {NULL, 0, 0},
  };
  return &source;
}

const rosidl_runtime_c__type_description__TypeSource *
custom_action_interfaces__action__DimLights_Result__get_individual_type_description_source(
  const rosidl_message_type_support_t * type_support)
{
  (void)type_support;
  static const rosidl_runtime_c__type_description__TypeSource source = {
    {custom_action_interfaces__action__DimLights_Result__TYPE_NAME, 48, 48},
    {implicit_encoding, 8, 8},
    {NULL, 0, 0},
  };
  return &source;
}

const rosidl_runtime_c__type_description__TypeSource *
custom_action_interfaces__action__DimLights_Feedback__get_individual_type_description_source(
  const rosidl_message_type_support_t * type_support)
{
  (void)type_support;
  static const rosidl_runtime_c__type_description__TypeSource source = {
    {custom_action_interfaces__action__DimLights_Feedback__TYPE_NAME, 50, 50},
    {implicit_encoding, 8, 8},
    {NULL, 0, 0},
  };
  return &source;
}

const rosidl_runtime_c__type_description__TypeSource *
custom_action_interfaces__action__DimLights_SendGoal__get_individual_type_description_source(
  const rosidl_service_type_support_t * type_support)
{
  (void)type_support;
  static const rosidl_runtime_c__type_description__TypeSource source = {
    {custom_action_interfaces__action__DimLights_SendGoal__TYPE_NAME, 50, 50},
    {implicit_encoding, 8, 8},
    {NULL, 0, 0},
  };
  return &source;
}

const rosidl_runtime_c__type_description__TypeSource *
custom_action_interfaces__action__DimLights_SendGoal_Request__get_individual_type_description_source(
  const rosidl_message_type_support_t * type_support)
{
  (void)type_support;
  static const rosidl_runtime_c__type_description__TypeSource source = {
    {custom_action_interfaces__action__DimLights_SendGoal_Request__TYPE_NAME, 58, 58},
    {implicit_encoding, 8, 8},
    {NULL, 0, 0},
  };
  return &source;
}

const rosidl_runtime_c__type_description__TypeSource *
custom_action_interfaces__action__DimLights_SendGoal_Response__get_individual_type_description_source(
  const rosidl_message_type_support_t * type_support)
{
  (void)type_support;
  static const rosidl_runtime_c__type_description__TypeSource source = {
    {custom_action_interfaces__action__DimLights_SendGoal_Response__TYPE_NAME, 59, 59},
    {implicit_encoding, 8, 8},
    {NULL, 0, 0},
  };
  return &source;
}

const rosidl_runtime_c__type_description__TypeSource *
custom_action_interfaces__action__DimLights_SendGoal_Event__get_individual_type_description_source(
  const rosidl_message_type_support_t * type_support)
{
  (void)type_support;
  static const rosidl_runtime_c__type_description__TypeSource source = {
    {custom_action_interfaces__action__DimLights_SendGoal_Event__TYPE_NAME, 56, 56},
    {implicit_encoding, 8, 8},
    {NULL, 0, 0},
  };
  return &source;
}

const rosidl_runtime_c__type_description__TypeSource *
custom_action_interfaces__action__DimLights_GetResult__get_individual_type_description_source(
  const rosidl_service_type_support_t * type_support)
{
  (void)type_support;
  static const rosidl_runtime_c__type_description__TypeSource source = {
    {custom_action_interfaces__action__DimLights_GetResult__TYPE_NAME, 51, 51},
    {implicit_encoding, 8, 8},
    {NULL, 0, 0},
  };
  return &source;
}

const rosidl_runtime_c__type_description__TypeSource *
custom_action_interfaces__action__DimLights_GetResult_Request__get_individual_type_description_source(
  const rosidl_message_type_support_t * type_support)
{
  (void)type_support;
  static const rosidl_runtime_c__type_description__TypeSource source = {
    {custom_action_interfaces__action__DimLights_GetResult_Request__TYPE_NAME, 59, 59},
    {implicit_encoding, 8, 8},
    {NULL, 0, 0},
  };
  return &source;
}

const rosidl_runtime_c__type_description__TypeSource *
custom_action_interfaces__action__DimLights_GetResult_Response__get_individual_type_description_source(
  const rosidl_message_type_support_t * type_support)
{
  (void)type_support;
  static const rosidl_runtime_c__type_description__TypeSource source = {
    {custom_action_interfaces__action__DimLights_GetResult_Response__TYPE_NAME, 60, 60},
    {implicit_encoding, 8, 8},
    {NULL, 0, 0},
  };
  return &source;
}

const rosidl_runtime_c__type_description__TypeSource *
custom_action_interfaces__action__DimLights_GetResult_Event__get_individual_type_description_source(
  const rosidl_message_type_support_t * type_support)
{
  (void)type_support;
  static const rosidl_runtime_c__type_description__TypeSource source = {
    {custom_action_interfaces__action__DimLights_GetResult_Event__TYPE_NAME, 57, 57},
    {implicit_encoding, 8, 8},
    {NULL, 0, 0},
  };
  return &source;
}

const rosidl_runtime_c__type_description__TypeSource *
custom_action_interfaces__action__DimLights_FeedbackMessage__get_individual_type_description_source(
  const rosidl_message_type_support_t * type_support)
{
  (void)type_support;
  static const rosidl_runtime_c__type_description__TypeSource source = {
    {custom_action_interfaces__action__DimLights_FeedbackMessage__TYPE_NAME, 57, 57},
    {implicit_encoding, 8, 8},
    {NULL, 0, 0},
  };
  return &source;
}

const rosidl_runtime_c__type_description__TypeSource__Sequence *
custom_action_interfaces__action__DimLights__get_type_description_sources(
  const rosidl_action_type_support_t * type_support)
{
  (void)type_support;
  static rosidl_runtime_c__type_description__TypeSource sources[16];
  static const rosidl_runtime_c__type_description__TypeSource__Sequence source_sequence = {sources, 16, 16};
  static bool constructed = false;
  if (!constructed) {
    sources[0] = *custom_action_interfaces__action__DimLights__get_individual_type_description_source(NULL),
    sources[1] = *builtin_interfaces__msg__Time__get_individual_type_description_source(NULL);
    sources[2] = *custom_action_interfaces__action__DimLights_Feedback__get_individual_type_description_source(NULL);
    sources[3] = *custom_action_interfaces__action__DimLights_FeedbackMessage__get_individual_type_description_source(NULL);
    sources[4] = *custom_action_interfaces__action__DimLights_GetResult__get_individual_type_description_source(NULL);
    sources[5] = *custom_action_interfaces__action__DimLights_GetResult_Event__get_individual_type_description_source(NULL);
    sources[6] = *custom_action_interfaces__action__DimLights_GetResult_Request__get_individual_type_description_source(NULL);
    sources[7] = *custom_action_interfaces__action__DimLights_GetResult_Response__get_individual_type_description_source(NULL);
    sources[8] = *custom_action_interfaces__action__DimLights_Goal__get_individual_type_description_source(NULL);
    sources[9] = *custom_action_interfaces__action__DimLights_Result__get_individual_type_description_source(NULL);
    sources[10] = *custom_action_interfaces__action__DimLights_SendGoal__get_individual_type_description_source(NULL);
    sources[11] = *custom_action_interfaces__action__DimLights_SendGoal_Event__get_individual_type_description_source(NULL);
    sources[12] = *custom_action_interfaces__action__DimLights_SendGoal_Request__get_individual_type_description_source(NULL);
    sources[13] = *custom_action_interfaces__action__DimLights_SendGoal_Response__get_individual_type_description_source(NULL);
    sources[14] = *service_msgs__msg__ServiceEventInfo__get_individual_type_description_source(NULL);
    sources[15] = *unique_identifier_msgs__msg__UUID__get_individual_type_description_source(NULL);
    constructed = true;
  }
  return &source_sequence;
}

const rosidl_runtime_c__type_description__TypeSource__Sequence *
custom_action_interfaces__action__DimLights_Goal__get_type_description_sources(
  const rosidl_message_type_support_t * type_support)
{
  (void)type_support;
  static rosidl_runtime_c__type_description__TypeSource sources[1];
  static const rosidl_runtime_c__type_description__TypeSource__Sequence source_sequence = {sources, 1, 1};
  static bool constructed = false;
  if (!constructed) {
    sources[0] = *custom_action_interfaces__action__DimLights_Goal__get_individual_type_description_source(NULL),
    constructed = true;
  }
  return &source_sequence;
}

const rosidl_runtime_c__type_description__TypeSource__Sequence *
custom_action_interfaces__action__DimLights_Result__get_type_description_sources(
  const rosidl_message_type_support_t * type_support)
{
  (void)type_support;
  static rosidl_runtime_c__type_description__TypeSource sources[1];
  static const rosidl_runtime_c__type_description__TypeSource__Sequence source_sequence = {sources, 1, 1};
  static bool constructed = false;
  if (!constructed) {
    sources[0] = *custom_action_interfaces__action__DimLights_Result__get_individual_type_description_source(NULL),
    constructed = true;
  }
  return &source_sequence;
}

const rosidl_runtime_c__type_description__TypeSource__Sequence *
custom_action_interfaces__action__DimLights_Feedback__get_type_description_sources(
  const rosidl_message_type_support_t * type_support)
{
  (void)type_support;
  static rosidl_runtime_c__type_description__TypeSource sources[1];
  static const rosidl_runtime_c__type_description__TypeSource__Sequence source_sequence = {sources, 1, 1};
  static bool constructed = false;
  if (!constructed) {
    sources[0] = *custom_action_interfaces__action__DimLights_Feedback__get_individual_type_description_source(NULL),
    constructed = true;
  }
  return &source_sequence;
}

const rosidl_runtime_c__type_description__TypeSource__Sequence *
custom_action_interfaces__action__DimLights_SendGoal__get_type_description_sources(
  const rosidl_service_type_support_t * type_support)
{
  (void)type_support;
  static rosidl_runtime_c__type_description__TypeSource sources[8];
  static const rosidl_runtime_c__type_description__TypeSource__Sequence source_sequence = {sources, 8, 8};
  static bool constructed = false;
  if (!constructed) {
    sources[0] = *custom_action_interfaces__action__DimLights_SendGoal__get_individual_type_description_source(NULL),
    sources[1] = *builtin_interfaces__msg__Time__get_individual_type_description_source(NULL);
    sources[2] = *custom_action_interfaces__action__DimLights_Goal__get_individual_type_description_source(NULL);
    sources[3] = *custom_action_interfaces__action__DimLights_SendGoal_Event__get_individual_type_description_source(NULL);
    sources[4] = *custom_action_interfaces__action__DimLights_SendGoal_Request__get_individual_type_description_source(NULL);
    sources[5] = *custom_action_interfaces__action__DimLights_SendGoal_Response__get_individual_type_description_source(NULL);
    sources[6] = *service_msgs__msg__ServiceEventInfo__get_individual_type_description_source(NULL);
    sources[7] = *unique_identifier_msgs__msg__UUID__get_individual_type_description_source(NULL);
    constructed = true;
  }
  return &source_sequence;
}

const rosidl_runtime_c__type_description__TypeSource__Sequence *
custom_action_interfaces__action__DimLights_SendGoal_Request__get_type_description_sources(
  const rosidl_message_type_support_t * type_support)
{
  (void)type_support;
  static rosidl_runtime_c__type_description__TypeSource sources[3];
  static const rosidl_runtime_c__type_description__TypeSource__Sequence source_sequence = {sources, 3, 3};
  static bool constructed = false;
  if (!constructed) {
    sources[0] = *custom_action_interfaces__action__DimLights_SendGoal_Request__get_individual_type_description_source(NULL),
    sources[1] = *custom_action_interfaces__action__DimLights_Goal__get_individual_type_description_source(NULL);
    sources[2] = *unique_identifier_msgs__msg__UUID__get_individual_type_description_source(NULL);
    constructed = true;
  }
  return &source_sequence;
}

const rosidl_runtime_c__type_description__TypeSource__Sequence *
custom_action_interfaces__action__DimLights_SendGoal_Response__get_type_description_sources(
  const rosidl_message_type_support_t * type_support)
{
  (void)type_support;
  static rosidl_runtime_c__type_description__TypeSource sources[2];
  static const rosidl_runtime_c__type_description__TypeSource__Sequence source_sequence = {sources, 2, 2};
  static bool constructed = false;
  if (!constructed) {
    sources[0] = *custom_action_interfaces__action__DimLights_SendGoal_Response__get_individual_type_description_source(NULL),
    sources[1] = *builtin_interfaces__msg__Time__get_individual_type_description_source(NULL);
    constructed = true;
  }
  return &source_sequence;
}

const rosidl_runtime_c__type_description__TypeSource__Sequence *
custom_action_interfaces__action__DimLights_SendGoal_Event__get_type_description_sources(
  const rosidl_message_type_support_t * type_support)
{
  (void)type_support;
  static rosidl_runtime_c__type_description__TypeSource sources[7];
  static const rosidl_runtime_c__type_description__TypeSource__Sequence source_sequence = {sources, 7, 7};
  static bool constructed = false;
  if (!constructed) {
    sources[0] = *custom_action_interfaces__action__DimLights_SendGoal_Event__get_individual_type_description_source(NULL),
    sources[1] = *builtin_interfaces__msg__Time__get_individual_type_description_source(NULL);
    sources[2] = *custom_action_interfaces__action__DimLights_Goal__get_individual_type_description_source(NULL);
    sources[3] = *custom_action_interfaces__action__DimLights_SendGoal_Request__get_individual_type_description_source(NULL);
    sources[4] = *custom_action_interfaces__action__DimLights_SendGoal_Response__get_individual_type_description_source(NULL);
    sources[5] = *service_msgs__msg__ServiceEventInfo__get_individual_type_description_source(NULL);
    sources[6] = *unique_identifier_msgs__msg__UUID__get_individual_type_description_source(NULL);
    constructed = true;
  }
  return &source_sequence;
}

const rosidl_runtime_c__type_description__TypeSource__Sequence *
custom_action_interfaces__action__DimLights_GetResult__get_type_description_sources(
  const rosidl_service_type_support_t * type_support)
{
  (void)type_support;
  static rosidl_runtime_c__type_description__TypeSource sources[8];
  static const rosidl_runtime_c__type_description__TypeSource__Sequence source_sequence = {sources, 8, 8};
  static bool constructed = false;
  if (!constructed) {
    sources[0] = *custom_action_interfaces__action__DimLights_GetResult__get_individual_type_description_source(NULL),
    sources[1] = *builtin_interfaces__msg__Time__get_individual_type_description_source(NULL);
    sources[2] = *custom_action_interfaces__action__DimLights_GetResult_Event__get_individual_type_description_source(NULL);
    sources[3] = *custom_action_interfaces__action__DimLights_GetResult_Request__get_individual_type_description_source(NULL);
    sources[4] = *custom_action_interfaces__action__DimLights_GetResult_Response__get_individual_type_description_source(NULL);
    sources[5] = *custom_action_interfaces__action__DimLights_Result__get_individual_type_description_source(NULL);
    sources[6] = *service_msgs__msg__ServiceEventInfo__get_individual_type_description_source(NULL);
    sources[7] = *unique_identifier_msgs__msg__UUID__get_individual_type_description_source(NULL);
    constructed = true;
  }
  return &source_sequence;
}

const rosidl_runtime_c__type_description__TypeSource__Sequence *
custom_action_interfaces__action__DimLights_GetResult_Request__get_type_description_sources(
  const rosidl_message_type_support_t * type_support)
{
  (void)type_support;
  static rosidl_runtime_c__type_description__TypeSource sources[2];
  static const rosidl_runtime_c__type_description__TypeSource__Sequence source_sequence = {sources, 2, 2};
  static bool constructed = false;
  if (!constructed) {
    sources[0] = *custom_action_interfaces__action__DimLights_GetResult_Request__get_individual_type_description_source(NULL),
    sources[1] = *unique_identifier_msgs__msg__UUID__get_individual_type_description_source(NULL);
    constructed = true;
  }
  return &source_sequence;
}

const rosidl_runtime_c__type_description__TypeSource__Sequence *
custom_action_interfaces__action__DimLights_GetResult_Response__get_type_description_sources(
  const rosidl_message_type_support_t * type_support)
{
  (void)type_support;
  static rosidl_runtime_c__type_description__TypeSource sources[2];
  static const rosidl_runtime_c__type_description__TypeSource__Sequence source_sequence = {sources, 2, 2};
  static bool constructed = false;
  if (!constructed) {
    sources[0] = *custom_action_interfaces__action__DimLights_GetResult_Response__get_individual_type_description_source(NULL),
    sources[1] = *custom_action_interfaces__action__DimLights_Result__get_individual_type_description_source(NULL);
    constructed = true;
  }
  return &source_sequence;
}

const rosidl_runtime_c__type_description__TypeSource__Sequence *
custom_action_interfaces__action__DimLights_GetResult_Event__get_type_description_sources(
  const rosidl_message_type_support_t * type_support)
{
  (void)type_support;
  static rosidl_runtime_c__type_description__TypeSource sources[7];
  static const rosidl_runtime_c__type_description__TypeSource__Sequence source_sequence = {sources, 7, 7};
  static bool constructed = false;
  if (!constructed) {
    sources[0] = *custom_action_interfaces__action__DimLights_GetResult_Event__get_individual_type_description_source(NULL),
    sources[1] = *builtin_interfaces__msg__Time__get_individual_type_description_source(NULL);
    sources[2] = *custom_action_interfaces__action__DimLights_GetResult_Request__get_individual_type_description_source(NULL);
    sources[3] = *custom_action_interfaces__action__DimLights_GetResult_Response__get_individual_type_description_source(NULL);
    sources[4] = *custom_action_interfaces__action__DimLights_Result__get_individual_type_description_source(NULL);
    sources[5] = *service_msgs__msg__ServiceEventInfo__get_individual_type_description_source(NULL);
    sources[6] = *unique_identifier_msgs__msg__UUID__get_individual_type_description_source(NULL);
    constructed = true;
  }
  return &source_sequence;
}

const rosidl_runtime_c__type_description__TypeSource__Sequence *
custom_action_interfaces__action__DimLights_FeedbackMessage__get_type_description_sources(
  const rosidl_message_type_support_t * type_support)
{
  (void)type_support;
  static rosidl_runtime_c__type_description__TypeSource sources[3];
  static const rosidl_runtime_c__type_description__TypeSource__Sequence source_sequence = {sources, 3, 3};
  static bool constructed = false;
  if (!constructed) {
    sources[0] = *custom_action_interfaces__action__DimLights_FeedbackMessage__get_individual_type_description_source(NULL),
    sources[1] = *custom_action_interfaces__action__DimLights_Feedback__get_individual_type_description_source(NULL);
    sources[2] = *unique_identifier_msgs__msg__UUID__get_individual_type_description_source(NULL);
    constructed = true;
  }
  return &source_sequence;
}
