// generated from rosidl_generator_c/resource/idl.h.em
// with input from custom_action_interfaces:action/DimLights.idl
// generated code does not contain a copyright notice

#ifndef CUSTOM_ACTION_INTERFACES__ACTION__DIM_LIGHTS_H_
#define CUSTOM_ACTION_INTERFACES__ACTION__DIM_LIGHTS_H_

#include "custom_action_interfaces/action/detail/dim_lights__struct.h"
#include "custom_action_interfaces/action/detail/dim_lights__functions.h"
#include "custom_action_interfaces/action/detail/dim_lights__type_support.h"

#endif  // CUSTOM_ACTION_INTERFACES__ACTION__DIM_LIGHTS_H_
